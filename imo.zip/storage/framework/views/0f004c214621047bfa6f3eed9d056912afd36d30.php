<div>
    <footer class="dark-footer skin-dark-footer">
        <div>
            <div class="container">
                <div class="row">
                    
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-widget">
                            <?php if(isset($footer->title)): ?>
                            <h4 class="widget-title text-bold"><?php echo e($footer->footer_title); ?></h4>
                            <?php endif; ?>
                            <?php if(isset($footer->footer_content)): ?>
                            <p><?php echo e($footer->footer_content); ?></p>
                            <?php endif; ?>
                            <?php if(isset($footer->andriod_app)): ?>
                            <a href="<?php echo e($footer->andriod_app); ?>" class="other-store-link">
                                <div class="other-store-app">
                                    <div class="os-app-icon">
                                        <i class="ti-android"></i>
                                    </div>
                                    <div class="os-app-caps">
                                        Google Store
                                    </div>
                                </div>
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>		
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-widget">
                            <h4 class="widget-title"><?php echo e(__('lang.usefullinks')); ?></h4>
                            <ul class="footer-menu">
                                <?php if(count($pages) > 0): ?>
                                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('page.view',$page->slug)); ?>"><?php echo e($page->title); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                            
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-widget">
                            <h4 class="widget-title"><?php echo e(__('lang.getintouch')); ?></h4>
                            <div class="fw-address-wrap">
                                <?php if(isset($footer->adress)): ?>
                                <div class="fw fw-location">
                                    <?php echo e($footer->adress); ?>

                                </div>
                                <?php endif; ?>
                                <?php if(isset($footer->email)): ?>
                                <div class="fw fw-mail">
                                    <?php echo e($footer->email); ?>

                                </div>
                                <?php endif; ?>
                                <?php if(isset($footer->phone)): ?>
                                <div class="fw fw-call">
                                    <?php echo e($footer->phone); ?>

                                </div>
                                <?php endif; ?>
                                <?php if(isset($footer->website)): ?>
                                <div class="fw fw-web">
                                   <?php echo e($footer->website); ?>

                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-widget">
                            <h4 class="widget-title"><?php echo e(__('lang.followus')); ?></h4>
                            <p><?php echo e(__('lang.followuscontent')); ?></p>
                            <ul class="footer-bottom-social">
                               <?php if(isset($footer->media)): ?>
                               <?php if($footer->media['facebook']): ?> <li><a href="<?php echo e($footer->media['facebook']); ?>"><i class="ti-facebook"></i></a></li> <?php endif; ?>
                               <?php if($footer->media['twitter']): ?>  <li><a href="<?php echo e($footer->media['twitter']); ?>"><i class="ti-twitter"></i></a></li><?php endif; ?>
                               <?php if($footer->media['instagram']): ?>  <li><a href="<?php echo e($footer->media['instagram']); ?>"><i class="ti-instagram"></i></a></li><?php endif; ?>
                               <?php if($footer->media['linkedin']): ?>  <li><a href="<?php echo e($footer->media['linkedin']); ?>"><i class="ti-linkedin"></i></a></li><?php endif; ?>
                               <?php endif; ?>     
                            </ul>
                            
                            <div class="f-newsletter mt-4">
                                <input wire:model.defer="email" type="email" class="form-control sigmup-me" placeholder="<?php echo e(__('lang.email')); ?>">
                                <button wire:click="save" type="submit" class="btn"><i class="ti-arrow-right"></i></button>
                            </div>
                            <p class="text-success"><?php echo e($msg); ?></p>
                             <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        
        <div class="footer-bottom">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-12 col-md-12 text-center">
                        <a href="<?php echo e(LaravelLocalization::getLocalizedURL('fr')); ?>">
                            <img width="50" height="50" class="rounded-circle" src="<?php echo e(asset('images/world/fr.jpg')); ?>"  alt="fr"/>
                        </a>
                        <a href="<?php echo e(LaravelLocalization::getLocalizedURL('en')); ?>">
                            <img width="50" height="50"  class="rounded-circle" src="<?php echo e(asset('images/world/en.jpg')); ?>"  alt="fr"/>
                        </a>
                    </div>
                    <div class="col-lg-12 col-md-12 text-center">
                        <p class="mb-0">© <?php echo e(date('Y')); ?> <a href="<?php echo e(route('home')); ?>"><?php echo e(config('app.name')); ?></a> <?php echo e(__('lang.allrightsreserved')); ?></p>
                    </div>
                    
                </div>
            </div>
        </div>
    </footer>
</div>
<?php /**PATH /home/diabcoog/gif/resources/views/livewire/footer.blade.php ENDPATH**/ ?>