<!DOCTYPE html>
<html>

<head>
		<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
		
    	
</head>
<body> 
<div class="container">
    <p class="text-danger">
        <?php echo e(Date('Y/M/D')); ?>

    </p>   
    <p class="text-bold text-center">
        <?php echo e(Config('app.name')); ?>

    </p>
    <div>
        <ul class="list-group list-group-horizontal">
            <li class="list-group-item"><?php echo e(__('lang.property')); ?> : <?php echo e($data->title); ?></li>
            <li class="list-group-item"><?php echo e(__('lang.propertytype')); ?> : 
                <?php if($data->propertytype == 'houses'): ?>  <?php echo e(__('lang.houses')); ?>  <?php endif; ?>
                <?php if($data->propertytype == 'apartment'): ?>  <?php echo e(__('lang.apartment')); ?>  <?php endif; ?>
                <?php if($data->propertytype == 'villas'): ?>  <?php echo e(__('lang.villas')); ?>  <?php endif; ?>
                <?php if($data->propertytype == 'commercial'): ?>  <?php echo e(__('lang.commercial')); ?>  <?php endif; ?>
                <?php if($data->propertytype == 'offices'): ?>  <?php echo e(__('lang.offices')); ?>  <?php endif; ?>
                <?php if($data->propertytype == 'garage'): ?>  <?php echo e(__('lang.garage')); ?>  <?php endif; ?>
                <?php if($data->propertytype == 'ground'): ?>  <?php echo e(__('lang.ground')); ?>  <?php endif; ?>
            </li>
            <li class="list-group-item"><?php echo e(__('lang.status')); ?> :
                <?php if($data->status == 'sale'): ?>   <?php echo e(__('lang.forsale')); ?> <?php endif; ?>
                <?php if($data->status == 'rent'): ?>   <?php echo e(__('lang.forrent')); ?>  <?php endif; ?>
            </li>
            <li class="list-group-item"><?php echo e(__('lang.price')); ?> : <?php echo e(config('helper.coin')); ?> <?php echo e($data->price); ?></li>
            <li class="list-group-item"><?php echo e(__('lang.energyclass')); ?> : <?php echo e($data->energy); ?></li>
            <li class="list-group-item"><?php echo e(__('lang.ges')); ?> : <?php echo e($data->ges); ?></li>
            <li class="list-group-item"><?php echo e(__('lang.area')); ?> : <?php echo e($data->area); ?></li>
            <li class="list-group-item"><?php echo e(__('lang.zipcode')); ?> : <?php echo e($data->zipcode); ?></li>
            <li class="list-group-item"><?php echo e(__('lang.address')); ?> : <?php echo e($data->address); ?></li>
            <li class="list-group-item"><?php echo e(__('lang.buildon')); ?> : <?php echo e($data->buildon); ?></li>
            <li class="list-group-item"><?php echo e(__('lang.bedrooms')); ?> : <?php echo e($data->bedrooms); ?></li>
            <li class="list-group-item"><?php echo e(__('lang.bathrooms')); ?> : <?php echo e($data->bathrooms); ?></li>
            <li class="list-group-item"><?php echo e(__('lang.rooms')); ?> :  <?php echo e($data->rooms); ?></li>
            <li class="list-group-item"><?php echo e(__('lang.name')); ?> : <?php echo e($data->name); ?></li>
            <li class="list-group-item"><?php echo e(__('lang.email')); ?> : <?php echo e($data->email); ?></li>
            <li class="list-group-item"><?php echo e(__('lang.phone')); ?> : <?php echo e($data->phone); ?></li>
            <li class="list-group-item"><?php echo e(__('lang.region')); ?> : <?php echo e($data->city->state->state); ?></li>
            <li class="list-group-item"><?php echo e(__('lang.city')); ?> : <?php echo e($data->city->city); ?></li>
          </ul>
    </div>
    <div>
        <h4 class="block-title"><?php echo e(__('lang.amenities')); ?></h4>
        <ul>
            <?php if($data->features != null && count($data->features) > 0): ?>
            <?php $__currentLoopData = $data->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $features): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($features == 'equippedkitchen'): ?>   <li><?php echo e(__('lang.equippedkitchen')); ?></li> <?php endif; ?>
              <?php if($features == 'americankitchen'): ?>   <li><?php echo e(__('lang.americankitchen')); ?></li> <?php endif; ?>
              <?php if($features == 'separatetoilet'): ?>   <li><?php echo e(__('lang.separatetoilet')); ?></li> <?php endif; ?>
              <?php if($features == 'bathtub'): ?>   <li><?php echo e(__('lang.bathtub')); ?></li> <?php endif; ?>
              <?php if($features == 'fireplace'): ?>   <li><?php echo e(__('lang.fireplace')); ?></li> <?php endif; ?>
              <?php if($features == 'airconditioner'): ?>   <li><?php echo e(__('lang.airconditioner')); ?></li> <?php endif; ?>
              <?php if($features == 'cupboards'): ?>   <li><?php echo e(__('lang.cupboards')); ?></li> <?php endif; ?>
              <?php if($features == 'parquet'): ?>   <li><?php echo e(__('lang.parquet')); ?></li> <?php endif; ?>
              <?php if($features == 'alarm'): ?>   <li><?php echo e(__('lang.alarm')); ?></li> <?php endif; ?>
              <?php if($features == 'attic'): ?>   <li><?php echo e(__('lang.attic')); ?></li> <?php endif; ?>
              <?php if($features == 'balcony'): ?>   <li><?php echo e(__('lang.balcony')); ?></li> <?php endif; ?>
              <?php if($features == 'terrace'): ?>   <li><?php echo e(__('lang.terrace')); ?></li> <?php endif; ?>
              <?php if($features == 'garden'): ?>   <li><?php echo e(__('lang.garden')); ?></li> <?php endif; ?>
              <?php if($features == 'garageparking'): ?>   <li><?php echo e(__('lang.garageparking')); ?></li> <?php endif; ?>
              <?php if($features == 'cellar'): ?>   <li><?php echo e(__('lang.cellar')); ?></li> <?php endif; ?>
              <?php if($features == 'swimmingpool'): ?>   <li><?php echo e(__('lang.swimmingpool')); ?></li> <?php endif; ?>
              <?php if($features == 'tennis'): ?>   <li><?php echo e(__('lang.tennis')); ?></li> <?php endif; ?>
              <?php if($features == 'elevator'): ?>   <li><?php echo e(__('lang.elevator')); ?></li> <?php endif; ?>
              <?php if($features == 'guardian'): ?>   <li><?php echo e(__('lang.guardian')); ?></li> <?php endif; ?>
              <?php if($features == 'digicode'): ?>   <li><?php echo e(__('lang.digicode')); ?></li> <?php endif; ?>
              <?php if($features == 'intercom'): ?>   <li><?php echo e(__('lang.intercom')); ?></li> <?php endif; ?>
              <?php if($features == 'calm'): ?>   <li><?php echo e(__('lang.calm')); ?></li> <?php endif; ?>
              <?php if($features == 'heater'): ?>   <li><?php echo e(__('lang.heater')); ?></li> <?php endif; ?>
              <?php if($features == 'luminous'): ?>   <li><?php echo e(__('lang.luminous')); ?></li> <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </ul>
    </div>
    <div class="row">
        <?php if(count($data->photos) > 0): ?>
        <?php $__currentLoopData = $data->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div class="col-md-6">
          <img width="600" height="400" src="<?php echo e(asset($photo)); ?>" />
       </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       <?php endif; ?>
    </div>
</div>
</body>
</html><?php /**PATH /home/diabcoog/gif/resources/views/pdf.blade.php ENDPATH**/ ?>