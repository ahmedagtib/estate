<div>
    <div class="page-title">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    
                    <h2 class="ipt-title"><?php echo e(__('lang.propertylist')); ?></h2>
                    <span class="ipn-subtitle"><?php echo e(__('lang.propertylisttitle')); ?></span>
                    
                </div>
            </div>
        </div>
    </div>
    <!-- ============================ Page Title End ================================== -->
    
    <!-- ============================ All Property ================================== -->
   
    <section>
    
        <div class="container">
            <div class="row">
                
                <div class="col-lg-8 col-md-12 list-layout">
                    <div class="row">
                    
                        <div class="col-lg-12 col-md-12">
                            <div class="filter-fl">
                                <h4><?php echo e(__('lang.totalpropertyfindis')); ?>:  <span class="theme-cl"><?php echo e($count); ?></span></h4>
                                <div>
                                    <select wire:model="order" class="custom-select" style="height: 35px;">
                                       <option value="price"><?php echo e(__('lang.sortbyprice')); ?></option>
                                       <option value="buildon"><?php echo e(__('lang.sortbybuildon')); ?></option>
                                       <option value="latest"><?php echo e(__('lang.sortbylatest')); ?></option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                    
                        <!-- Single Property Start -->
                        <?php if(count($data) > 0): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div   class="col-lg-12 col-md-12">
                            <div  class="property-listing property-1">
                                    
                                <div class="listing-img-wrapper">
                                    <a href="<?php echo e(route('property',['slug'=>$property->slug])); ?>">
                                    <?php if(!empty($property->thumbnails[0])): ?>
                                    <img src="<?php echo e(asset($property->thumbnails[0])); ?>" class="img-fluid mx-auto" alt="<?php echo e($property->title); ?>" title="<?php echo e($property->title); ?>" />
                                    <?php endif; ?>
                                    <?php if(empty($property->thumbnails[0])): ?>
                                    <img src="<?php echo e(asset('images/property/default.jpg')); ?>" class="img-fluid mx-auto" alt="<?php echo e($property->title); ?>"  title="<?php echo e($property->title); ?>"/>
                                    <?php endif; ?>
                                    </a>
                                    <div class="listing-like-top">
                                        <i class="ti-heart"></i>
                                    </div>
                                    <div class="listing-rating">
                                        <span class="text-danger text-bold">  <?php echo e($property->city->city); ?></span>
                                    </div>
                                    <?php if($property->status == 'rent'): ?><span class="property-type"><?php echo e(__('lang.forrent')); ?></span><?php endif; ?>
                                    <?php if($property->status == 'sale'): ?><span class="property-type"><?php echo e(__('lang.forsale')); ?></span><?php endif; ?>
                                </div>
                                
                                <div class="listing-content">
                                
                                    <div class="listing-detail-wrapper">
                                        <div class="listing-short-detail">
                                            <h4 class="listing-name"><a href="<?php echo e(route('property',['slug'=>$property->slug])); ?>"><?php echo e($property->title); ?></a></h4>
                                            <span class="listing-location"><i class="ti-location-pin"></i><?php echo e($property->address); ?></span>
                                        </div>
                                    </div>
                                
                                    <div class="listing-features-info">
                                        <ul>
                                         <?php if($property->propertytype == 'houses' || $property->propertytype == 'apartment' || $property->propertytype == 'villas'): ?>    
                                         <?php if($property->bedrooms): ?><li><strong><?php echo e(__('lang.beds')); ?>:</strong><?php echo e($property->bedrooms); ?></li><?php endif; ?>
                                         <?php if($property->bathrooms): ?><li><strong><?php echo e(__('lang.bath')); ?>:</strong><?php echo e($property->bathrooms); ?></li><?php endif; ?>
                                         <?php if($property->area): ?><li><strong><?php echo e(__('lang.area')); ?>:</strong><?php echo e($property->area); ?></li><?php endif; ?>
                                         <?php else: ?> 
                                         <?php if($property->area): ?><li><strong><?php echo e(__('lang.area')); ?>:</strong><?php echo e($property->area); ?></li><?php endif; ?>
                                         <?php endif; ?>
                                        </ul>
                                    </div>
                                
                                    <div class="listing-footer-wrapper">
                                        <div class="listing-price">
                                            <h4 class="list-pr"><?php echo e(config('helper.coin')); ?> <?php echo e($property->price); ?></h4>
                                        </div>
                                        <div class="listing-detail-btn">
                                            <a href="<?php echo e(route('property',['slug'=>$property->slug])); ?>" class="more-btn"><?php echo e(__('lang.moreinfo')); ?></a>
                                        </div>
                                    </div>
                                    
                                </div>
                                
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <!-- Single Property End -->
                        <?php else: ?>
                        <div class="alert  alert-danger texr-white">
                             Result not found 
                        </div>
                        <?php endif; ?>
                        

                        
					
                        
                    </div>
                    
                    <!-- Pagination -->
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <ul class="pagination p-center">
                                <?php echo e($data->links()); ?>

                            </ul>
                        </div>
                    </div>
            
                </div>
                
                <!-- property Sidebar -->
                <div class="col-lg-4 col-md-12 col-sm-12">
                    <div  class="page-sidebar">
                        
                        <!-- Find New Property -->
                        <div   class="sidebar-widgets">
                            
                            <h4><?php echo e(__('lang.findnewproperty')); ?></h4>
                            
                            <div class="form-group">
                                <select wire:model.defer="type"  class="custom-select">
                                    <option value="houses">    <?php echo e(__('lang.houses')); ?></option>
                                    <option value="apartment"> <?php echo e(__('lang.apartment')); ?></option>
                                    <option value="villas">    <?php echo e(__('lang.villas')); ?></option>
                                    <option value="commercial"><?php echo e(__('lang.commercial')); ?></option>
                                    <option value="offices">   <?php echo e(__('lang.offices')); ?></option>
                                    <option value="garage">    <?php echo e(__('lang.garage')); ?></option>
                                    <option value="ground">    <?php echo e(__('lang.ground')); ?></option>
                                </select>
                                <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="form-group">
                                        <div  wire:model.defer="minprice"  class="input-with-icon">
                                            <input type="text" class="form-control" placeholder="Minimum">
                                            <i><?php echo e(config('helper.coin')); ?></i>
                                        </div>
                                        <?php $__errorArgs = ['minprice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="form-group">
                                        <div class="input-with-icon">
                                            <input wire:model.defer="maxprice" type="text" class="form-control" placeholder="Maximum">
                                            <i><?php echo e(config('helper.coin')); ?></i>
                                        </div>
                                        <?php $__errorArgs = ['maxprice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <div class="input-with-icon">
                                    <select wire:model.defer="bedrooms"  class="form-control custom-select">
                                        <option value=""><?php echo e(__('lang.bedrooms')); ?></option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                    </select>
                                    <i class="fas fa-bed"></i>
                                </div>
                                <?php $__errorArgs = ['bedrooms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="form-group">
                                <div class="input-with-icon">
                                    <select  wire:model.defer="bathrooms" class="form-control custom-select">
                                        <option value=""><?php echo e(__('lang.bathrooms')); ?></option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                    </select>
                                    <i class="fas fa-bath"></i>
                                    <?php $__errorArgs = ['bathrooms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <div>
                                    <select  wire:model.defer="status"  class="custom-select">
                                        <option value="rent"><?php echo e(__('lang.forrent')); ?></option>
                                        <option value="sale"><?php echo e(__('lang.forsale')); ?></option>
                                    </select>
                                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <div>
                                    <select wire:model="stateId" class="custom-select">
                                        <?php $__currentLoopData = $allstate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($state->id); ?>"><?php echo e($state->state); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div>
                                    <select wire:model="city_id" class="custom-select">
                                        <?php $__currentLoopData = $allcities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($city->id); ?>"><?php echo e($city->city); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['city_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            
                    
                            <div class="ameneties-features">
                                <div class="form-group" id="module">
                                    <a role="button" class="" data-toggle="collapse" href="#advance-search" aria-expanded="true" aria-controls="advance-search"></a>
                                </div>
                                <div class="collapse" id="advance-search" aria-expanded="false" role="banner">
                                    <ul class="no-ul-list">
                                        <li>
                                            <input id="a-1" class="checkbox-custom" name="a-1" type="checkbox">
                                            <label for="a-1" class="checkbox-custom-label">Air Condition</label>
                                        </li>
                                        <li>
                                            <input id="a-2" class="checkbox-custom" name="a-2" type="checkbox">
                                            <label for="a-2" class="checkbox-custom-label">Bedding</label>
                                        </li>
                                        <li>
                                            <input id="a-3" class="checkbox-custom" name="a-3" type="checkbox">
                                            <label for="a-3" class="checkbox-custom-label">Heating</label>
                                        </li>
                                        <li>
                                            <input id="a-4" class="checkbox-custom" name="a-4" type="checkbox">
                                            <label for="a-4" class="checkbox-custom-label">Internet</label>
                                        </li>
                                        <li>
                                            <input id="a-5" class="checkbox-custom" name="a-5" type="checkbox">
                                            <label for="a-5" class="checkbox-custom-label">Microwave</label>
                                        </li>
                                        <li>
                                            <input id="a-6" class="checkbox-custom" name="a-6" type="checkbox">
                                            <label for="a-6" class="checkbox-custom-label">Smoking Allow</label>
                                        </li>
                                        <li>
                                            <input id="a-7" class="checkbox-custom" name="a-7" type="checkbox">
                                            <label for="a-7" class="checkbox-custom-label">Terrace</label>
                                        </li>
                                        <li>
                                            <input id="a-8" class="checkbox-custom" name="a-8" type="checkbox">
                                            <label for="a-8" class="checkbox-custom-label">Balcony</label>
                                        </li>
                                        <li>
                                            <input id="a-9" class="checkbox-custom" name="a-9" type="checkbox">
                                            <label for="a-9" class="checkbox-custom-label">Icon</label>
                                        </li>
                                    </ul>
                                </div>
                            
                                <button wire:click="search()" class="btn btn-theme full-width"><?php echo e(__('lang.findnewhome')); ?></button>
                            
                            </div>
                    
                        </div>
                    </div>
                    <!-- Sidebar End -->
                
                </div>
            </div>
        </div>	
    </section>
    <?php if(Session::has('top')): ?>
<script>
   $('#back2Top').click();
</script>
<?php endif; ?>

</div>


<?php /**PATH /home/diabcoog/gif/resources/views/livewire/listing-properties.blade.php ENDPATH**/ ?>