<div>
    <div class="page-title">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    
                    <h2 class="ipt-title"><?php echo e(__('lang.contactus')); ?></h2>
                    <span class="ipn-subtitle"><?php echo e(__('lang.descriptioncontactus')); ?></span>
                    
                </div>
            </div>
        </div>
    </div>
    <!-- ============================ Page Title End ================================== -->
    
    <!-- ============================ Agency List Start ================================== -->
    <section>
    
        <div class="container">
        
            <!-- row Start -->
            <div class="row">
            
                <div class="col-lg-7 col-md-7">
                    
                    <div class="row">
                        <div class="col-lg-6 col-md-6">
                            <div class="form-group">
                                <label><?php echo e(__('lang.fullname')); ?></label>
                                <input wire:model="name" type="text" class="form-control simple">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="form-group">
                                <label><?php echo e(__('lang.email')); ?></label>
                                <input wire:model="email" type="email" class="form-control simple">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label><?php echo e(__('lang.subject')); ?></label>
                        <input wire:model="subject" type="text" class="form-control simple">
                        <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="form-group">
                        <label><?php echo e(__('lang.message')); ?></label>
                        <textarea wire:model="message" class="form-control simple"></textarea>
                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="form-group">
                        <button  wire:click="sendmail" class="btn btn-theme" type="submit"><?php echo e(__('lang.send')); ?></button>
                    </div>
                                    
                </div>
                
                <div class="col-lg-5 col-md-5">
                    <div class="contact-info">
                        
                        <?php if(isset($settingcontact->contact_title)): ?><h2><?php echo e($settingcontact->contact_title); ?></h2><?php endif; ?>
                        <?php if(isset($settingcontact->contact_content)): ?>
                        <p><?php echo e($settingcontact->contact_content); ?></p>
                        <?php endif; ?>
                        
                        <div class="cn-info-detail">
                            <div class="cn-info-icon">
                                <i class="ti-home"></i>
                            </div>
                            <div class="cn-info-content">
                                <?php if(isset($settingcontact->adress)): ?>
                                <h4 class="cn-info-title"><?php echo e(__('lang.reachus')); ?></h4>
                                <?php echo e($settingcontact->adress); ?>

                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="cn-info-detail">
                            <div class="cn-info-icon">
                                <i class="ti-email"></i>
                            </div>
                            <div class="cn-info-content">
                                <?php if(isset($settingcontact->email)): ?>
                                <h4 class="cn-info-title"><?php echo e(__('lang.dropamail')); ?></h4>
                                  <?php echo e($settingcontact->email); ?>

                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="cn-info-detail">
                            <div class="cn-info-icon">
                                <i class="ti-mobile"></i>
                            </div>
                            <div class="cn-info-content">
                                <?php if(isset($settingcontact->phone)): ?>
                                <h4 class="cn-info-title"><?php echo e(__('lang.callus')); ?></h4>
                                <?php echo e($settingcontact->phone); ?>

                                <?php endif; ?>
                            </div>
                        </div>
                        
                    </div>
                </div>
                
            </div>
            <!-- /row -->		
            
        </div>
                
    </section>
</div>
<?php /**PATH C:\xampp\htdocs\imo\resources\views/livewire/contact-us.blade.php ENDPATH**/ ?>