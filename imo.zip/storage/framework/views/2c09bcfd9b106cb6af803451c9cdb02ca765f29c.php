<div>
    <div class="page-title">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    
                    <h2 class="ipt-title"><?php echo e(__('lang.welcome')); ?></h2>
                    <span class="ipn-subtitle"><?php echo e(__('lang.welcome_to_your_account')); ?></span>
                    <?php if(Auth::user()->email_verified_at == null): ?>
                         <div class="alert alert-warning mt-4">
                                <?php echo e(__('lang.account_not_verified')); ?> - <a class="text-warning" href="<?php echo e(route('email.verify')); ?>"><?php echo e(__('lang.click')); ?></a>
                         </div>
                    <?php endif; ?>                    
                </div>
            </div>
        </div>
    </div>
    <section>
        <div class="container">
           <div class="row">
              <?php echo $__env->make('account.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <div class="col-lg-8 col-md-12">
                 <div class="dashboard-wraper">
                    <div class="form-submit">
                        <h4><?php echo e(__('lang.findbylocation')); ?></h4>
                      <div class="form-group">
                           <label><?php echo e(__('lang.imagecdn')); ?></label>
                           <input type="text" class="form-control" wire:model="imagecdn" />
                           <p class="text-danger"><?php $__errorArgs = ['imagecdn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                      </div>
                      <div class="form-group">
                        <label><?php echo e(__('lang.url')); ?></label>
                        <input type="text" class="form-control" wire:model="url" />
                        <p class="text-danger"><?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                     </div>
                     <div class="form-group">
                        <label><?php echo e(__('lang.cityname')); ?></label>
                        <input type="text" class="form-control" wire:model="cityname" />
                        <p class="text-danger"><?php $__errorArgs = ['cityname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                     </div>
                     <div class="form-group">
                        <label><?php echo e(__('lang.numberproperty')); ?></label>
                        <input type="text" class="form-control" wire:model="numberproperty" />
                        <p class="text-danger"><?php $__errorArgs = ['numberproperty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                     </div>
                     <div class="form-group">
                         <button wire:click="save" class="btn btn-success text-white"><?php echo e(__('lang.send')); ?></button>
                         <button wire:click="clear" class="btn btn-info text-white"><?php echo e(__('lang.cleardata')); ?></button>
                     </div>
                    </div>
                    <div class="clearfix"></div>
                  <div wire:ignore>
                     <?php if(isset($allcdn)  && count($allcdn) > 0): ?>
                     <table class="table">
                        <thead>
                           <tr>
                              <th><?php echo e(__('lang.imagecdn')); ?></th>
                              <th><?php echo e(__('lang.cityname')); ?></th>
                              <th><?php echo e(__('lang.numberproperty')); ?></th>
                           </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $allcdn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td>
                                 <img src="<?php echo e($d['imagecdn']); ?>"  width="60" height="60" />
                              </td>
                              <td><?php echo e($d['cityname']); ?></td>
                              <td><?php echo e($d['numberproperty']); ?></td>
                           </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                     </table>
                     <?php endif; ?>
                  </div>
                 </div>
              </div>
           </div>
        </div>
        </div>
     </section>    

</div>



<?php /**PATH C:\xampp\htdocs\imo\resources\views/livewire/admin/find-by-location.blade.php ENDPATH**/ ?>