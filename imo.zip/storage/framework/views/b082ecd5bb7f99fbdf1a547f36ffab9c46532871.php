    <div wire:ignore.self class="modal fade" id="login" tabindex="-1" role="dialog" aria-labelledby="registermodal" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered login-pop-form" role="document">
            <div class="modal-content" id="registermodal">
                <span class="mod-close" data-dismiss="modal" aria-hidden="true"><i class="ti-close"></i></span>
                <div class="modal-body">
                    <h4 class="modal-header-title"><?php echo e(__('lang.login')); ?></h4>
                    <div class="login-form">
                        <form wire:submit.prevent="login">
                            <h4 class="text-center text-danger">
                                <?php echo e($error); ?>

                            </h4>
                            <div class="form-group">
                                <label><?php echo e(__('lang.email')); ?></label>
                                <div class="input-with-icon">
                                    <input type="email" wire:model.defer="email" class="form-control" placeholder="<?php echo e(__('lang.email')); ?>">
                                    <i class="ti-email"></i>
                                </div>
                                <p class="text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                            </div>
                            
                            <div class="form-group">
                                <label><?php echo e(__('lang.password')); ?></label>
                                <div class="input-with-icon">
                                    <input type="password" wire:model.defer="password" class="form-control" placeholder="*******">
                                    <i class="ti-unlock"></i>
                                </div>
                                <p class="text-danger"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                            </div>
                            
                            <div class="form-group">
                                <button type="submit" class="btn btn-md full-width pop-login">
                                    <?php echo e(__('lang.login')); ?>

                                    <span class="spinner-border text-light" role="status" wire:loading wire:target="login">
                                      
                                    </span>
                                </button>
                            </div>
                        
                        </form>
                    </div>
                    <?php if($theme->facebook || $theme->gmail): ?>
                    <div class="modal-divider"><span><?php echo e(__('lang.or_login_via')); ?></span></div>
                    <?php endif; ?>
                    <div class="social-login mb-3">
                        <ul>
                            <?php if($theme->facebook): ?>
                            <li><a href="<?php echo e(route('auth.facebook')); ?>" class="btn connect-fb"><i class="ti-facebook"></i>Facebook</a></li>
                            <?php endif; ?>
                            <?php if($theme->gmail): ?>
                            <li><a href="<?php echo e(route('auth.google')); ?>" class="btn connect-google"><i class="ti-google"></i>Gmail</a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <div class="text-center">
                        <p class="mt-5"><a href="<?php echo e(route('forgot.password')); ?>" class="link"><?php echo e(__('lang.forgot_password')); ?></a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php /**PATH /home/diabcoog/gif/resources/views/livewire/auth/login.blade.php ENDPATH**/ ?>