<div>
    <div class="page-title">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    
                    <h2 class="ipt-title"><?php echo e(__('lang.welcome')); ?></h2>
                    <span class="ipn-subtitle"><?php echo e(__('lang.welcome_to_your_account')); ?></span>
                    <?php if(Auth::user()->email_verified_at == null): ?>
                         <div class="alert alert-warning mt-4">
                                <?php echo e(__('lang.account_not_verified')); ?> - <a class="text-warning" href="<?php echo e(route('email.verify')); ?>"><?php echo e(__('lang.click')); ?></a>
                         </div>
                    <?php endif; ?>
                    <?php if(Session::has('success')): ?>
                      <div class="alert alert-success mt-4">
                           <?php echo e(session::get('success')); ?> 
                      </div>
                    <?php endif; ?>
                    <?php if(Session::has('error')): ?>
                      <div class="alert alert-danger mt-4">
                           <?php echo e(session::get('error')); ?> 
                      </div>
                    <?php endif; ?>
                    
                </div>
            </div>
        </div>
    </div>
    
    <section>
        <div class="container">
            <div class="row">
                 <?php echo $__env->make('account.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-lg-8 col-md-12">
                    <div class="dashboard-wraper">
                    
                        <!-- Basic Information -->
                        <div class="form-submit">	
                            <h4><?php echo e(__('lang.myaccount')); ?></h4>
                            <div class="submit-section">
                                <div class="form-row">
                                
                                    <div class="form-group col-md-6">
                                        <label><?php echo e(__('lang.fullname')); ?></label>
                                        <input type="text" wire:model="fullname" class="form-control" value="Shaurya Preet">
                                        <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    
                                    <div class="form-group col-md-6">
                                        <label><?php echo e(__('lang.email')); ?></label>
                                        <input disabled type="email" wire:model="email" class="form-control"  value="preet77@gmail.com">
                                   
                                    </div>
                                    
                                    <div class="form-group col-md-6">
                                        <label><?php echo e(__('lang.title')); ?></label>
                                        <input type="text" wire:model="title" class="form-control" value="Web Designer">
                                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    
                                    <div class="form-group col-md-6">
                                        <label><?php echo e(__('lang.phone')); ?></label>
                                        <input type="text" wire:model="phone" class="form-control" value="123 456 5847">
                                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    
                                    <div class="form-group col-md-6">
                                        <label><?php echo e(__('lang.address')); ?></label>
                                        <input type="text" wire:model="address" class="form-control" value="522, Arizona, Canada">
                                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    
                                    <div class="form-group col-md-6">
                                        <label><?php echo e(__('lang.city')); ?></label>
                                        <input type="text" wire:model="city" class="form-control" value="Montquebe">
                                        <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    
                                    <div class="form-group col-md-12">
                                        <label><?php echo e(__('lang.aboutyou')); ?></label>
                                        <textarea class="form-control" wire:model="aboutyou">Maecenas quis consequat libero, a feugiat eros. Nunc ut lacinia tortor morbi ultricies laoreet ullamcorper phasellus semper</textarea>
                                        <?php $__errorArgs = ['aboutyou'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label ><?php echo e(__('lang.yourphoto')); ?></label>
                                        <input type="file" wire:model="photo"  placeholder="<?php echo e(__('lang.choosephoto')); ?>">
                                        <label class="custom-file-label">
                                            <i class="ti-camera ti-2x"></i>  
                                        </label>   
                                        <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-6">
                                    <?php if($photo): ?>
                                        <img class="rounded" src="<?php echo e($photo->temporaryUrl()); ?>" width="80" height="80" />
                                     <?php endif; ?>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-submit">	
                            <h4><?php echo e(__('lang.socialaccounts')); ?></h4>
                            <div class="submit-section">
                                <div class="form-row">
                                
                                    <div class="form-group col-md-6">
                                        <label>Facebook</label>
                                        <input type="text" wire:model="facebook" class="form-control" value="https://facebook.com/">
                                    </div>
                                    
                                    <div class="form-group col-md-6">
                                        <label>Twitter</label>
                                        <input type="email" wire:model="twitter" class="form-control" value="https://twitter.com/">
                                    </div>
                                    
                                    <div class="form-group col-md-6">
                                        <label>Instagram</label>
                                        <input type="text"  wire:model="instagram" class="form-control" value="https://instagram.com/">
                                    </div>
                                    
                                    <div class="form-group col-md-6">
                                        <label>LinkedIn</label>
                                        <input type="text" wire:model="linkedin" class="form-control" value="https://linkedin.com/">
                                    </div>
                                </div>
                
                                
                                <div class="form-group col-lg-12 col-md-12">
                                    <button class="btn btn-theme" type="submit" wire:click="save"><?php echo e(__('lang.savechanges')); ?></button>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
                
            </div>
        </div>
    </section>
</div>
<?php /**PATH /home/diabcoog/gif/resources/views/livewire/user/profile.blade.php ENDPATH**/ ?>