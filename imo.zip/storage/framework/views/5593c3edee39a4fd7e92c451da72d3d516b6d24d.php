<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
		<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <title><?php echo e($metatitle  ??  config('helper.metatitle')); ?></title>
		<meta name="description" content="<?php echo e($metadescription ??  config('helper.metadescription')); ?>">
		<meta name="keywords" content="<?php echo e($metakeyword  ??  config('helper.metakeyword')); ?>">
		<meta name="author" content="<?php echo e(config('helper.author')); ?>"> 
		<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
		<link rel="shortcut icon" href="/favicon.ico">
		<?php echo $__env->yieldContent('meta'); ?>
		<link rel="stylesheet" href="<?php echo e(asset('css/plugins.css')); ?>"/>
		<link rel="stylesheet" href="<?php echo e(asset('css/nav.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>"/>
		<link rel="stylesheet" href="<?php echo e(asset('css/colors.css')); ?>" />
		<!--   
		<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-select.min.css')); ?>" />
		-->
		<link rel="stylesheet" href="<?php echo e(asset('css/toastr.min.css')); ?>" />

		<?php echo $__env->yieldContent('style'); ?>
		<?php echo \Livewire\Livewire::styles(); ?>

		
		
</head>
<body class="<?php echo e(Request::routeIs('blog') ? 'blog-page purple-skin' : 'purple-skin'); ?>"> 
	<div id="preloader"><div class="preloader"><span></span><span></span></div></div>
		
    <div id="main-wrapper">
          <!-- Start Navigation -->
          <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('navbar')->html();
} elseif ($_instance->childHasBeenRendered('NNNRW2q')) {
    $componentId = $_instance->getRenderedChildComponentId('NNNRW2q');
    $componentTag = $_instance->getRenderedChildComponentTagName('NNNRW2q');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NNNRW2q');
} else {
    $response = \Livewire\Livewire::mount('navbar');
    $html = $response->html();
    $_instance->logRenderedChild('NNNRW2q', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
          <!-- End Navigation -->
		  <div class="clearfix"></div>
           <?php echo $__env->yieldContent('content'); ?>
         
         <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

	<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
	<!--
	<script src="<?php echo e(asset('js/rangeslider.js')); ?>"></script>
	<script src="<?php echo e(asset('js/slider-bg.js')); ?>"></script>
	-->
	<script src="<?php echo e(asset('js/aos.js')); ?>"></script>
	<script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery.magnific-popup.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/slick.js')); ?>"></script>
	
	<script src="<?php echo e(asset('js/lightbox.js')); ?>"></script> 
	<script src="<?php echo e(asset('js/imagesloaded.js')); ?>"></script>
	<script src="<?php echo e(asset('js/isotope.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/coreNavigation.js')); ?>"></script>
	<script src="<?php echo e(asset('js/custom.js')); ?>"></script>
	<script src="<?php echo e(asset('js/cl-switch.js')); ?>"></script>
	<script src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>
	<script>
	    var route      = "<?php echo e(route('save.token')); ?>"; 
	    var csrf_token = "<?php echo e(csrf_token()); ?>"; 
	    var apiKey     =  "<?php echo e(Config('helper.firebase_apiKey')); ?>";
        var authDomain =  "<?php echo e(Config('helper.firebase_authDomain')); ?>";
        var projectId  =  "<?php echo e(Config('helper.firebase_projectId')); ?>";
        var storageBucket = "<?php echo e(Config('helper.firebase_storageBucket')); ?>";
        var messagingSenderId = "<?php echo e(Config('helper.firebase_messagingSenderId')); ?>";
        var appId = "<?php echo e(Config('helper.firebase_appId')); ?>";
        var vapidKey = "<?php echo e(Config('helper.firebase_vapidKey')); ?>";
	</script>
	<script src="https://www.gstatic.com/firebasejs/8.7.1/firebase-app.js"></script>
	<script src="https://www.gstatic.com/firebasejs/8.7.1/firebase-messaging.js"></script>
	<!--
	<script src="https://www.gstatic.com/firebasejs/7.23.0/firebase-messaging.js"></script>
	-->
	
	<script src="<?php echo e(asset('index/index3.js')); ?>"></script>
 	<?php echo $__env->yieldContent('scripts'); ?>
	<script>
		<?php if(Session::has('message')): ?>
		toastr.options =
		{
			"closeButton" : true,
			"progressBar" : true
		}
				toastr.success("<?php echo e(session('message')); ?>");
		<?php endif; ?>
	  
		<?php if(Session::has('error')): ?>
		toastr.options =
		{
			"closeButton" : true,
			"progressBar" : true
		}
				toastr.error("<?php echo e(session('error')); ?>");
		<?php endif; ?>
	  
		<?php if(Session::has('info')): ?>
		toastr.options =
		{
			"closeButton" : true,
			"progressBar" : true
		}
				toastr.info("<?php echo e(session('info')); ?>");
		<?php endif; ?>
	  
		<?php if(Session::has('warning')): ?>
		toastr.options =
		{
			"closeButton" : true,
			"progressBar" : true
		}
				toastr.warning("<?php echo e(session('warning')); ?>");
		<?php endif; ?>
	  </script>
   
   <?php echo $__env->yieldContent('script'); ?>

	<?php echo \Livewire\Livewire::scripts(); ?>


	
	<a id="back2Top" class="top-scroll" title="Back to top" href="#" style="display: inline;"><i class="ti-arrow-up"></i></a>

</body>
</html><?php /**PATH /home/diabcoog/gif/resources/views/layouts/app.blade.php ENDPATH**/ ?>