<div>
    <div class="page-title">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    
                    <h2 class="ipt-title"><?php echo e(__('lang.welcome')); ?></h2>
                    <span class="ipn-subtitle"><?php echo e(__('lang.welcome_to_your_account')); ?></span>
                    <?php if(Auth::user()->email_verified_at == null): ?>
                         <div class="alert alert-warning mt-4">
                                <?php echo e(__('lang.account_not_verified')); ?> - <a class="text-warning" href="<?php echo e(route('email.verify')); ?>"><?php echo e(__('lang.click')); ?></a>
                         </div>
                    <?php endif; ?>                    
                </div>
            </div>
        </div>
    </div>
    <section>
        <div class="container">
           <div class="row">
              <?php echo $__env->make('account.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <div class="col-lg-8 col-md-12">
                 <div class="dashboard-wraper">
                    <div class="form-submit">
                    <div class="d-flex justify-content-between">
                        <h4><?php echo e(__('lang.blogmanage')); ?></h4>
                        <a class="btn btn-primary text-white" href="<?php echo e(route('blog.create')); ?>"><?php echo e(__('lang.createblog')); ?></a>
                    </div>
                    <div class="mt-2">
                        <input class="form-control" wire:model="titleSearch" placeholder="<?php echo e(__('lang.searchbytitle')); ?>"/>
                    </div>
                    <div class="mt-2">
                        <?php if($posts->count() > 0): ?>
                        <table class="table">
                            <thead>
                              <tr>
                                <th scope="col">#</th>
                                <th scope="col"><?php echo e(__('lang.titleblog')); ?></th>
                                <th scope="col"><?php echo e(__('lang.blogphoto')); ?></th>
                                <th scope="col"><?php echo e(__('lang.statue')); ?></th>
                                <th scope="col"><?php echo e(__('lang.action')); ?></th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($post->id); ?></th>
                                    <td><?php echo e($post->title); ?></td>
                                    <td>
                                        <img width="50" height="50" src="<?php echo e(asset($post->photo)); ?>" alt="#"/>
                                    </td>
                                    <td>
                                        <?php if($post->statue == 'pending'): ?>
                                        <span class="badge badge-warning"><?php echo e(__('lang.pending')); ?></span>
                                        <?php endif; ?>
                                        <?php if($post->statue == 'publiched'): ?>
                                         <span class="badge badge-success"><?php echo e(__('lang.published')); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('blog.update',$post->id)); ?>" class="btn btn-warning">
                                            <i class="ti-pencil-alt"></i> 
                                        </a>
                                        <button wire:click="delete(<?php echo e($post->id); ?>)" class="btn btn-danger">
                                            <i class="ti-trash"></i> 
                                        </button>
                                    </td>
                                  </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($posts->links()); ?>

                        <?php endif; ?>
                    </div>
                    </div>
                 </div>
              </div>
           </div>
        </div>
        </div>
     </section>    

</div>



<?php /**PATH /home/diabcoog/gif/resources/views/livewire/admin/manage-blog.blade.php ENDPATH**/ ?>