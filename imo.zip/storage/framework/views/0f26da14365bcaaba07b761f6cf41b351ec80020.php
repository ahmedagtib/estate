<div>
    <div class="page-title">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    
                    <h2 class="ipt-title"><?php echo e(__('lang.welcome')); ?></h2>
                    <span class="ipn-subtitle"><?php echo e(__('lang.welcome_to_your_account')); ?></span>
                    <?php if(Auth::user()->email_verified_at == null): ?>
                         <div class="alert alert-warning mt-4">
                                <?php echo e(__('lang.account_not_verified')); ?> - <a class="text-warning" href="<?php echo e(route('email.verify')); ?>"><?php echo e(__('lang.click')); ?></a>
                         </div>
                    <?php endif; ?>                    
                </div>
            </div>
        </div>
    </div>
    <section>
        <div class="container">
            <div class="row">
                 <?php echo $__env->make('account.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-lg-8 col-md-12">
                    <div class="dashboard-wraper">
                        <h4><?php echo e(__('lang.allpage')); ?></h4>
                        <a href="<?php echo e(route('page.create')); ?>" class="btn btn-primary text-white"><?php echo e(__('lang.createnewpage')); ?></a>
                        <table class="table mt-2">
                            <thead>
                              <tr>
                                <th scope="col">#</th>
                                <th scope="col"><?php echo e(__('lang.image')); ?></th>
                                <th scope="col"><?php echo e(__('lang.pagetitle')); ?></th>
                                <th scope="col"><?php echo e(__('lang.action')); ?></th>
                            </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $allpages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                    <th scope="row"><?php echo e($page->id); ?></th>
                                    <td>
                                        <img src="<?php echo e(asset($page->image)); ?>" width="50" height="50" />
                                    </td>
                                    <td><?php echo e($page->title); ?></td>
            
                                    <td>
                                        <a  href="<?php echo e(route('page.update',['id'=>$page->id])); ?>"  class="btn btn-warning">
                                            <i class="ti-pencil-alt"></i> 
                                        </a>
                                        <button  wire:click="delete(<?php echo e($page->id); ?>)" class="btn btn-danger">
                                            <i class="ti-trash"></i> 
                                        </button>
                                    </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

</div>


<?php /**PATH /home/diabcoog/gif/resources/views/livewire/admin/pages-manage.blade.php ENDPATH**/ ?>