
<?php $__env->startSection('content'); ?>
<section>
    <div class="container">
        <div class="row">
             <div class="col-md-6 mx-auto">
                 <h1 class="text-center"><?php echo e(__('lang.reset_password')); ?></h1>
                 <form method="POST">
                     <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <div class="input-with-icon">
                            <input  type="email" disabled name="email" class="form-control" placeholder="<?php echo e(__('lang.email')); ?>" value="<?php echo e($email); ?>" />
                            <i class="ti-email"></i>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-with-icon">
                            <input  type="password" name="password"  class="form-control" placeholder="<?php echo e(__('lang.password')); ?>">
                            <i class="ti-password"></i>
                        </div>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <p class="text-danger"><?php echo e($message); ?></p>  
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>         
                    </div>
                    <div class="form-group">
                        <div class="input-with-icon">
                            <input  type="password" name="password_confirmation"   class="form-control" placeholder="<?php echo e(__('lang.password_confirmation')); ?>">
                            <i class="ti-password"></i>
                            <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>  
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
                        </div>
                    </div>
                    <div class="form-group">
                        <button  type="submit" class="btn btn-theme-2 btn-block"><?php echo e(__('lang.send')); ?></button>
                    </div>
                 </form>
    
             </div>
        </div>
    </div>
    </section>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/diabcoog/gif/resources/views/account/user/restpassword.blade.php ENDPATH**/ ?>