<div class="agent-widget">
    <div class="agent-title">
        <?php if($prop->user): ?>
        <div class="agent-photo"><img src="<?php echo e(($prop->user->avatar) ?asset($prop->user->avatar) : asset('images/avatar/default.jpg')); ?>" alt="<?php echo e($prop->user->fullname); ?>"></div>
        <?php else: ?>
        <div class="agent-photo"><img src="<?php echo e(asset('images/avatar/default.jpg')); ?>" alt=""></div> 
        <?php endif; ?>
        <div  class="agent-details">
            <h4 wire:ignore><span><?php echo e($prop->name); ?></span></h4>
           
            <?php if(!$show): ?>
            <button wire:click="$set('show',true)" class="btn btn-success btn-sm"><i class="lni-phone-handset"></i>
                <?php echo e(__('lang.phone')); ?>

            </button>
            <?php else: ?>
                <span><i class="lni-phone-handset"></i><?php echo e($phone); ?></span>
            <?php endif; ?>
        </div>
        <div class="clearfix"></div>
    </div>
   <div>
    <div class="form-group">
        <input type="text" wire:model.defer="email" class="form-control" placeholder="<?php echo e(__('lang.email')); ?>">
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group">
        <input type="text" wire:model.defer="phoneclient" class="form-control" placeholder="<?php echo e(__('lang.phone')); ?>">
        <?php $__errorArgs = ['phoneclient'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group">
        <textarea wire:model.defer="messageproperty" class="form-control"></textarea>
        <?php $__errorArgs = ['messageproperty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <button wire:click="send()" class="btn btn-theme full-width"><?php echo e(__('lang.send')); ?></button>
   </div>
    
</div>
<?php /**PATH /home/diabcoog/gif/resources/views/livewire/component/mail-property.blade.php ENDPATH**/ ?>