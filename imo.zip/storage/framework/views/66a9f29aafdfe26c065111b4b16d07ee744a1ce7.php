<div>
    <div class="page-title">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    
                    <h2 class="ipt-title"><?php echo e(__('lang.welcome')); ?></h2>
                    <span class="ipn-subtitle"><?php echo e(__('lang.welcome_to_your_account')); ?></span>
                    <?php if(Auth::user()->email_verified_at == null): ?>
                         <div class="alert alert-warning mt-4">
                                <?php echo e(__('lang.account_not_verified')); ?> - <a class="text-warning" href="<?php echo e(route('email.verify')); ?>"><?php echo e(__('lang.click')); ?></a>
                         </div>
                    <?php endif; ?>                    
                </div>
            </div>
        </div>
    </div>
    
    <section>
        <div class="container">
            <div class="row">
                 <?php echo $__env->make('account.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-lg-8 col-md-12">
                    <div class="dashboard-wraper">
                    
                        <!-- Basic Information -->
                        <div class="form-submit">	
                            <h4><?php echo e(__('lang.managecities')); ?></h4>
                            <div class="submit-section">
                                <div class="form-row">
                                    <div class="form-group col-md-8">
                                        <div class="form-group">
                                            <div class="input-with-icon">
                                                <label><?php echo e(__('lang.choosecity')); ?> - <?php echo e($state_id); ?></label>
                                                <select wire:model="state_id"   class="custom-select form-control"  style="color:#868e96;" >
                                                    <?php if($allstates->count() > 0): ?> 
                                                    <option  value="-1"><?php echo e(__('lang.choosecity')); ?></option>  
                                                        <?php $__currentLoopData = $allstates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option  value="<?php echo e($state->id); ?>" ><?php echo e($state->state); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                    <option  value="-1"><?php echo e(__('lang.nostatefound')); ?></option>  
                                                    <?php endif; ?>
                                                </select> 
                                            </div>
                                            <p class="text-danger"><?php $__errorArgs = ['state_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-8">
                                        <label><?php echo e(__('lang.entercity')); ?></label>
                                        <input type="hidden" wire:model="idcity" value="idstate"/>
                                        <input type="text" wire:model="city" class="form-control" placeholder="<?php echo e(__('lang.entercity')); ?>">
                                        <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div> 
                                    <div class="form-group col-lg-12 col-md-12">
                                       <?php if($button): ?>
                                        <button class="btn btn-warning" type="submit" wire:click="update()"><?php echo e(__('lang.savechanges')); ?></button>
                                        <button class="btn btn-info" type="submit" wire:click="clear()"><?php echo e(__('lang.clear')); ?></button>
                                       <?php else: ?>
                                        <button class="btn btn-theme" type="submit" wire:click="save"><?php echo e(__('lang.send')); ?></button>
                                       <?php endif; ?> 
                                   </div> 
                                </div>
                            </div>
                            <?php if($allcity): ?>
                            <table class="table">
                                <thead>
                                  <tr>
                                    <th scope="col">#</th>
                                    <th scope="col"><?php echo e(__('lang.city')); ?></th>
                                    <th scope="col"><?php echo e(__('lang.state')); ?></th>
                                    <th scope="col"><?php echo e(__('lang.action')); ?></th>
                                </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $allcity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                        <th scope="row"><?php echo e($c->id); ?></th>
                                        <td><?php echo e($c->city); ?></td>
                                        <td><?php echo e($c->state->state); ?></td>
                                        <td>
                                            <button wire:click="edit(<?php echo e($c->id); ?>)" class="btn btn-warning">
                                                <i class="ti-pencil-alt"></i> 
                                            </button>
                                            <button wire:click="delete(<?php echo e($c->id); ?>)" class="btn btn-danger">
                                                <i class="ti-trash"></i> 
                                            </button>
                                        </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                            </table>
                            <?php endif; ?>
                        </div>
                        <?php echo e($allcity->links()); ?>

                    
                         </div>
                        </div>
                        
                    </div>
                </div>
                
            </div>
        </div>
    </section>
</div>

<?php /**PATH /home/diabcoog/gif/resources/views/livewire/admin/city.blade.php ENDPATH**/ ?>