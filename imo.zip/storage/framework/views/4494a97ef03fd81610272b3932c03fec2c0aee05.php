<div>
    <div class="page-title">
       <div class="container">
          <div class="row">
             <div class="col-lg-12 col-md-12">
                <h2 class="ipt-title"><?php echo e(__('lang.welcome')); ?></h2>
                <span class="ipn-subtitle"><?php echo e(__('lang.welcome_to_your_account')); ?></span>
                <?php if(Auth::user()->email_verified_at == null): ?>
                <div class="alert alert-warning mt-4">
                   <?php echo e(__('lang.account_not_verified')); ?> - <a class="text-warning" href="<?php echo e(route('email.verify')); ?>"><?php echo e(__('lang.click')); ?></a>
                </div>
                <?php endif; ?>                    
             </div>
          </div>
       </div>
    </div>
    <section>
       <div class="container">
          <div class="row">
             <?php echo $__env->make('account.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <div class="col-lg-8 col-md-12">
                <div class="dashboard-wraper">
                      <h4><?php echo e(__('lang.setting')); ?> <?php if($errors->any()): ?><span class="text-danger"> - <?php echo e(__('lang.valdtionerrorform')); ?></span><?php endif; ?></h4>
                      <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item mt-2" role="presentation">
                          <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="false"><?php echo e(__('lang.home')); ?></a>
                        </li>
                        <li class="nav-item mt-2" role="presentation">
                          <a class="nav-link" id="footer-tab" data-toggle="tab" href="#footer" role="tab" aria-controls="footer" aria-selected="false"><?php echo e(__('lang.footer')); ?></a>
                        </li>
                        <li class="nav-item mt-2" role="presentation">
                          <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false"><?php echo e(__('lang.contact')); ?></a>
                        </li>
                        <li class="nav-item mt-2" role="presentation">
                            <a class="nav-link" id="website-tab" data-toggle="tab" href="#website" role="tab" aria-controls="website" aria-selected="false"><?php echo e(__('lang.website')); ?></a>
                        </li>
                        <li class="nav-item mt-2" role="presentation">
                            <a class="nav-link" id="meta-tab" data-toggle="tab" href="#meta" role="tab" aria-controls="meta" aria-selected="false"><?php echo e(__('lang.seo')); ?></a>
                        </li>
                      </ul>
                      <div class="tab-content" id="myTabContent">
                        <div  wire:ignore.self  class="tab-pane fade active show"   id="home" role="tabpanel" aria-labelledby="home-tab">
                            <h6 class="text-center mt-1"><?php echo e(__('lang.contenthomepage')); ?></h6>
                            <div class="submit-page">
                                 <div class="submit-section mt-1">
                                    <div class="form-group">
                                       <label><?php echo e(__('lang.homebuttonsearch')); ?></label>
                                       <input type="text" wire:model="button_search_form" class="form-control" placeholder="<?php echo e(__('lang.homebuttonsearch')); ?>">
                                       <?php $__errorArgs = ['button_search_form'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                       <label><?php echo e(__('lang.herotitle')); ?></label>
                                       <input type="text" wire:model="hero_title" class="form-control" placeholder="<?php echo e(__('lang.herotitle')); ?>">
                                       <?php $__errorArgs = ['hero_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                       <label><?php echo e(__('lang.herocontent')); ?></label>
                                       <textarea type="text" wire:model="hero_content" class="form-control" placeholder="<?php echo e(__('lang.herocontent')); ?>"></textarea>
                                       <?php $__errorArgs = ['hero_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                       <button class="btn btn-primary text-white" wire:click="savehome()"><?php echo e(__('lang.send')); ?></button>
                                    </div>
                                 </div>
                            </div>
                        </div>
                        <div wire:ignore.self  class="tab-pane fade" id="footer" role="tabpanel" aria-labelledby="footer-tab">
                           <h6 class="text-center mt-1"><?php echo e(__('lang.footer')); ?></h6>
                           <div class="submit-page">
                                <div   class="submit-section mt-1">
                                   <div class="form-group">
                                      <label><?php echo e(__('lang.footertitle')); ?></label>
                                      <input type="text" wire:model="footer_title" class="form-control" placeholder="<?php echo e(__('lang.footertitle')); ?>">
                                      <?php $__errorArgs = ['footer_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                   </div>
                                   <div class="form-group">
                                      <label><?php echo e(__('lang.footercontent')); ?></label>
                                      <textarea type="text" wire:model="footer_content" class="form-control" placeholder="<?php echo e(__('lang.footercontent')); ?>"></textarea>
                                      <?php $__errorArgs = ['footer_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                   </div>
                                   <div class="form-group">
                                      <label><?php echo e(__('lang.andriodapp')); ?></label>
                                      <input type="text" wire:model="andriod_app" class="form-control" placeholder="<?php echo e(__('lang.andriodapp')); ?>"/>
                                      <?php $__errorArgs = ['andriod_app'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                   </div>
                                   <div class="form-group">
                                    <label><?php echo e(__('lang.fallowtitle')); ?></label>
                                    <input type="text" wire:model="follow_title" class="form-control" placeholder="<?php echo e(__('lang.fallowtitle')); ?>"/>
                                    <?php $__errorArgs = ['follow_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                                   <div class="form-group">
                                      <button class="btn btn-primary text-white" wire:click="savefooter()"><?php echo e(__('lang.send')); ?></button>
                                   </div>
                                </div>
                           </div>
                        </div>
                        <div wire:ignore.self class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                           <h6 class="text-center mt-1"><?php echo e(__('lang.contact')); ?></h6>
                           <div class="submit-page">
                                <div   class="submit-section mt-1">
                                   <div class="form-group">
                                      <label><?php echo e(__('lang.email')); ?></label>
                                      <input type="text" wire:model="email" class="form-control" placeholder="<?php echo e(__('lang.email')); ?>">
                                      <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                   </div>
                                   <div class="form-group">
                                      <label><?php echo e(__('lang.phone')); ?></label>
                                      <input type="text" wire:model="phone" class="form-control" placeholder="<?php echo e(__('lang.phone')); ?>" />
                                      <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                   </div>
                                   <div class="form-group">
                                      <label><?php echo e(__('lang.address')); ?></label>
                                      <input type="text" wire:model="adress" class="form-control" placeholder="<?php echo e(__('lang.andriodapp')); ?>"/>
                                      <?php $__errorArgs = ['adress'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                   </div>
                                   <div class="form-group">
                                    <label><?php echo e(__('lang.website')); ?></label>
                                    <input type="text" wire:model="website" class="form-control" placeholder="<?php echo e(__('lang.website')); ?>"/>
                                    <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                                   <div class="form-group">
                                    <label><?php echo e(__('lang.contacttitle')); ?></label>
                                    <input type="text" wire:model="contact_title" class="form-control" placeholder="<?php echo e(__('lang.fallowtitle')); ?>"/>
                                    <?php $__errorArgs = ['contact_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                                 <div class="form-group">
                                    <label><?php echo e(__('lang.contactcontent')); ?></label>
                                    <input type="text" wire:model="contact_content" class="form-control" placeholder="<?php echo e(__('lang.contactcontent')); ?>"/>
                                    <?php $__errorArgs = ['contact_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                                   <div class="form-group">
                                      <button class="btn btn-primary text-white" wire:click="savecontact()"><?php echo e(__('lang.send')); ?></button>
                                   </div>
                                </div>
                           </div>
                        </div>
                        <div wire:ignore.self  class="tab-pane fade" id="website" role="tabpanel" aria-labelledby="website-tab">
                           <h6 class="text-center mt-1"><?php echo e(__('lang.website')); ?></h6>
                           <div class="submit-page">
                                <div   class="submit-section mt-1">
                                   <div class="form-group">
                                      <label><?php echo e(__('lang.logo')); ?></label>
                                      <input type="file" wire:model="logo" class="form-control" placeholder="<?php echo e(__('lang.logo')); ?>">
                                      <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                   </div>
                                   <div class="form-group">
                                      <label><?php echo e(__('lang.facebook')); ?></label>
                                      <input type="text" wire:model="facebook" class="form-control" placeholder="<?php echo e(__('lang.facebook')); ?>"/>
                                      <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                   </div>
                                   <div class="form-group">
                                    <label><?php echo e(__('lang.instagram')); ?></label>
                                    <input type="text" wire:model="instagram" class="form-control" placeholder="<?php echo e(__('lang.instagram')); ?>"/>
                                    <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                                 <div class="form-group">
                                    <label><?php echo e(__('lang.twitter')); ?></label>
                                    <input type="text" wire:model="twitter" class="form-control" placeholder="<?php echo e(__('lang.twitter')); ?>"/>
                                    <?php $__errorArgs = ['twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                                 <div class="form-group">
                                    <label><?php echo e(__('lang.linkedin')); ?></label>
                                    <input type="text" wire:model="linkedin" class="form-control" placeholder="<?php echo e(__('lang.linkedin')); ?>"/>
                                    <?php $__errorArgs = ['linkedin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                               
                                 <div class="form-group">
                                      <button class="btn btn-primary text-white" wire:click="savewebsite()"><?php echo e(__('lang.send')); ?></button>
                                 </div>
                                </div>
                           </div>
                        </div>
                        <div wire:ignore.self class="tab-pane fade" id="meta" role="tabpanel" aria-labelledby="meta-tab">
                           <h6 class="text-center mt-1"><?php echo e(__('lang.seo')); ?></h6>
                           <div class="submit-page">
                                <div class="submit-section mt-1">
                                   <div class="form-group">
                                      <label><?php echo e(__('lang.metatitle')); ?></label>
                                      <input type="text" wire:model="meta_title" class="form-control" placeholder="<?php echo e(__('lang.metatitle')); ?>">
                                      <?php $__errorArgs = ['meta_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                   </div>
                                   <div class="form-group">
                                      <label><?php echo e(__('lang.metacontent')); ?></label>
                                      <textarea type="text" wire:model="meta_description" class="form-control" placeholder="<?php echo e(__('lang.metacontent')); ?>"></textarea>
                                      <?php $__errorArgs = ['meta_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                   </div>
                                   <div class="form-group">
                                      <label><?php echo e(__('lang.metakeyword')); ?></label>
                                      <textarea type="text" wire:model="meta_keyword" class="form-control" placeholder="<?php echo e(__('lang.metakeyword')); ?>"></textarea>
                                      <?php $__errorArgs = ['meta_keyword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                   </div>
                                   <div class="form-group">
                                      <button class="btn btn-primary text-white" wire:click="saveseo()"><?php echo e(__('lang.send')); ?></button>
                                   </div>
                                </div>
                           </div>
                        </div>
                      </div>
                      

                </div>
             </div>
          </div>
       </div>
    </section>
 </div>
 
 <?php /**PATH /home/diabcoog/gif/resources/views/livewire/admin/setting-manage.blade.php ENDPATH**/ ?>