
<?php $__env->startSection('content'); ?>
<div class="page-title">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                
                <h2 class="ipt-title"><?php echo e($page->title); ?></h2>                
            </div>
        </div>
    </div>
</div>
<!-- ============================ Page Title End ================================== -->

<!-- ============================ Agency List Start ================================== -->
<section>

    <div class="container">
    
        <!-- row Start -->
        <div class="row">
        
            <!-- Blog Detail -->
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="blog-details single-post-item format-standard">
                    <div class="post-details">
                    
                        <div class="post-featured-img">
                            <img class="img-fluid" src="<?php echo e(asset($page->image)); ?>" alt="<?php echo e($page->title); ?>">
                        </div>
                        
                        <div class="post-top-meta">
                            <ul class="meta-comment-tag">
                                <li><a href="#"><span class="icons"><i class="ti-user"></i></span><?php echo e(__('lang.by')); ?> <?php echo e(config('app.name')); ?></a></li>
                            </ul>
                        </div>
                        <h2 class="post-title"><?php echo e($page->title); ?></h2>
                        <div>
                            <?php echo $page->content; ?>

                        </div>
                       
                      
                        
                    </div>
                </div>
                
               
                
                
            </div>
        </div>
        <!-- /row -->					
        
    </div>
            
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/diabcoog/gif/resources/views/frontblog/page.blade.php ENDPATH**/ ?>