<?php $__env->startComponent('mail::message'); ?>
# <?php echo e(__('lang.hillo')); ?> <?php echo e($name); ?>


<?php echo e(config('app.name')); ?> - <?php echo e(__('lang.email_description_register')); ?>


<a href="<?php echo e(route('home')); ?>" class="button  button-primary"><?php echo e(config('app.name')); ?></a>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\imo\resources\views/emails/auth/register.blade.php ENDPATH**/ ?>