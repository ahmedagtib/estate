	<!-- ============================ Footer Start ================================== -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('footer')->html();
} elseif ($_instance->childHasBeenRendered('kIor49A')) {
    $componentId = $_instance->getRenderedChildComponentId('kIor49A');
    $componentTag = $_instance->getRenderedChildComponentTagName('kIor49A');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('kIor49A');
} else {
    $response = \Livewire\Livewire::mount('footer');
    $html = $response->html();
    $_instance->logRenderedChild('kIor49A', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <!-- ============================ Footer End ================================== -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('login')->html();
} elseif ($_instance->childHasBeenRendered('AzGZdYV')) {
    $componentId = $_instance->getRenderedChildComponentId('AzGZdYV');
    $componentTag = $_instance->getRenderedChildComponentTagName('AzGZdYV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AzGZdYV');
} else {
    $response = \Livewire\Livewire::mount('login');
    $html = $response->html();
    $_instance->logRenderedChild('AzGZdYV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('register')->html();
} elseif ($_instance->childHasBeenRendered('lhBWVgw')) {
    $componentId = $_instance->getRenderedChildComponentId('lhBWVgw');
    $componentTag = $_instance->getRenderedChildComponentTagName('lhBWVgw');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lhBWVgw');
} else {
    $response = \Livewire\Livewire::mount('register');
    $html = $response->html();
    $_instance->logRenderedChild('lhBWVgw', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH /home/diabcoog/gif/resources/views/layouts/footer.blade.php ENDPATH**/ ?>