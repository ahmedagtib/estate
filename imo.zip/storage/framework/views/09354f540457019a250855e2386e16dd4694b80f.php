<div>
    <div class="header header-light">
        <nav class="headnavbar">
            <div class="nav-header">
                <a href="<?php echo e(route('home')); ?>" class="brand"><img src="<?php echo e(asset($logo)); ?>" alt="<?php echo e(Config('app.name')); ?>" /></a>
                <button class="toggle-bar"><span class="ti-align-justify"></span></button>	
            </div>								
            <ul class="menu">
            
                <li><a href="<?php echo e(route('home')); ?>"><?php echo e(__('lang.home')); ?></a></li>
             
                
                <li class="dropdown">
                    <a href="JavaScript:Void(0);"><?php echo e(__('lang.properties')); ?></a>
                    <ul class="dropdown-menu">
                        <li><a href="<?php echo e(route('list.properties')); ?>"><?php echo e(__('lang.allproperties')); ?></a></li>                                    
                        <li><a href="<?php echo e(route('rent.properties')); ?>"><?php echo e(__('lang.propertiesrent')); ?></a></li>                                    
                        <li><a href="<?php echo e(route('sale.properties')); ?>"><?php echo e(__('lang.propertiessale')); ?></a></li>   
                    </ul>
                </li>
                
                <li><a href="<?php echo e(route('blogs')); ?>"><?php echo e(__('lang.blogs')); ?></a></li> 
                <li>
                    <a href="<?php echo e(route('contactus')); ?>"><?php echo e(__('lang.contactus')); ?></a>                                
                </li>
                <?php if(!Auth::check()): ?>
                <li><a href="#" data-toggle="modal" data-target="#signup"><?php echo e(__('lang.sign_up')); ?></a></li>
                <?php endif; ?>

            </ul>
             <?php if(auth()->guard()->check()): ?> 
             <ul class="attributes">
                <li class="login-attri">
                    <div class="btn-group account-drop">
                        <button type="button" class="btn btn-order-by-filt" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                           <?php if(!empty(Auth::user()->avatar)): ?> 
                            <img src="<?php echo e(asset(Auth::user()->avatar)); ?>" class="avater-img" alt=""><?php echo e(__('lang.hillo')); ?> <?php echo e(Auth::user()->fullname); ?>

                           <?php else: ?> 
                            <img src="<?php echo e(asset('images/avatar/default.jpg')); ?>" class="avater-img" alt="<?php echo e(Auth::user()->fullname); ?>" title="<?php echo e(Auth::user()->fullname); ?>">
                            <span class="d-none d-sm-block"><?php echo e(__('lang.hillo')); ?> <?php echo e(Auth::user()->fullname); ?></span>
  
                           <?php endif; ?>
                        </button>
                        <div class="dropdown-menu pull-right animated flipInX">
                            <a href="<?php echo e(route('profile')); ?>"><i class="ti-user"></i><?php echo e(__('lang.myprofile')); ?></a>                                  
                            <a href="<?php echo e(route('myproperty')); ?>"><i class="ti-layers"></i><?php echo e(__('lang.myproperty')); ?></a>                                                                     
                            <a  href="<?php echo e(route('update.password')); ?>"><i class="ti-unlock"></i><?php echo e(__('lang.updatepassword')); ?></a>
                            <a  href="<?php echo e(route('logout')); ?>" ><i class="ti-power-off"></i><?php echo e(__('lang.logout')); ?></a> 
                        </div>
                    </div>
                </li>
            </ul>
             <?php else: ?>
            <ul class="attributes">
                <li class="login-attri theme-log"><a href="#" data-toggle="modal" data-target="#login"><?php echo e(__('lang.login')); ?></a></li>
                <li class="submit-attri theme-log">
                    <a href="<?php echo e(route('create.property')); ?>"><?php echo e(__('lang.submitproperty')); ?></a>
                </li>
            </ul>
            <?php endif; ?>
            
        </nav>
    </div>
</div>
<?php /**PATH /home/diabcoog/gif/resources/views/livewire/navbar.blade.php ENDPATH**/ ?>