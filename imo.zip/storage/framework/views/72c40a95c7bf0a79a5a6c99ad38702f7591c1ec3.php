
<?php $__env->startSection('content'); ?>

<div class="image-cover hero-banner"  style="background:url(<?php echo e(asset('img/city.svg')); ?>) no-repeat;">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('component.search-form')->html();
} elseif ($_instance->childHasBeenRendered('YlvOMwR')) {
    $componentId = $_instance->getRenderedChildComponentId('YlvOMwR');
    $componentTag = $_instance->getRenderedChildComponentTagName('YlvOMwR');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YlvOMwR');
} else {
    $response = \Livewire\Livewire::mount('component.search-form');
    $html = $response->html();
    $_instance->logRenderedChild('YlvOMwR', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php if($theme == 1): ?>
<?php if(!empty($about->hero_title) && !empty($about->hero_content)): ?>
<section>
    <div class="container">
        <div class="row align-items-center">
            
            <div class="col-lg-6 col-md-6">
                <img src="<?php echo e(asset('img/sb.png')); ?>" class="img-fluid" alt="<?php echo e($about->hero_title); ?>"> 
            </div>
            
            <div class="col-lg-6 col-md-6">
                <div class="explore-content">
                    <h2><?php echo e($about->hero_title); ?></h2>
                    <p><?php echo e($about->hero_content); ?></p>
                  
                    <a href="<?php echo e(route('list.properties')); ?>" class="btn btn-theme-2"><?php echo e(__('lang.explorebypopular')); ?></a>
                </div>
            </div>
            
        </div>
        
    </div>		
</section>    
<?php endif; ?>
<?php else: ?>
<section>
    <div class="container">
        
        <div class="row">
            <div class="col text-center">
                <div class="sec-heading center">
                    <h2><?php echo e(__('lang.howitworks')); ?></h2>
                    <p><?php echo e(__('lang.howtostartworkwithusandworkingprocess')); ?></p>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-lg-4 col-md-4">
                <div class="middle-icon-features">
                    <div class="middle-icon-features-item">
                        <div class="middle-icon-large-features-box"><i class="ti-user text-danger"></i><span class="steps bg-danger">01</span></div>
                        <div class="middle-icon-features-content">
                            <h4><?php echo e(__('lang.createanaccount')); ?></h4>
                            <p><?php echo e(__('lang.createanaccountdesc')); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-4">
                <div class="middle-icon-features">
                    <div class="middle-icon-features-item">
                        <div class="middle-icon-large-features-box"><i class="ti-search text-success"></i><span class="steps bg-success">02</span></div>
                        <div class="middle-icon-features-content">
                            <h4><?php echo e(__('lang.findsearchproperty')); ?></h4>
                            <p><?php echo e(__('lang.findsearchpropertydesc')); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-4">
                <div class="middle-icon-features">
                    <div class="middle-icon-features-item">
                        <div class="middle-icon-large-features-box"><i class="ti-location-arrow text-warning"></i><span class="steps bg-warning">03</span></div>
                        <div class="middle-icon-features-content">
                            <h4><?php echo e(__('lang.bookyourproperty')); ?></h4>
                            <p><?php echo e(__('lang.bookyourpropertydesc')); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
</section>
<div class="clearfix"></div>
<?php endif; ?>
<?php if(count($data) > 0): ?>
<section class="gray-bg">
    <div class="container">
    
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <h2><?php echo e(__('lang.browseallproperty')); ?></h2>
            </div>
        </div>
        
        <div class="row">  
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="property-listing property-2">
                    
                    <div class="listing-img-wrapper">
                        <div class="list-img-slide">
                            <div class="click">
                                <?php if(!empty($item->thumbnails[0])  && count($item->thumbnails) > 0): ?>
                                <?php $__currentLoopData = $item->thumbnails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!empty($photo)): ?>
                                <div>
                                    <a href="<?php echo e(route('property',$item->slug)); ?>">
                                       <img src="<?php echo e(asset($photo)); ?>" class="img-fluid mx-auto" alt="<?php echo e($item->title); ?>" title="<?php echo e($item->title); ?>"  />
                                   </a>
                                </div>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?> 
                                <div>
                                    <a href="<?php echo e(route('property',$item->slug)); ?>">
                                       <img src="<?php echo e(asset('images/property/default.jpg')); ?>" class="img-fluid mx-auto" alt="<?php echo e($item->title); ?>" />
                                   </a>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <span class="property-type" style="background: rgba(255,255,255,0.98);">
                            <?php if($item->status == 'rent'): ?> 
                               <span class="text-warning"><?php echo e(__('lang.forrent')); ?> </span>  
                             <?php endif; ?>
                            <?php if($item->status == 'sale'): ?> 
                            <span class="text-success"> <?php echo e(__('lang.forsale')); ?>  </span>  
                                <?php endif; ?>
                        </span>
                    </div>
                    
                    <div class="listing-detail-wrapper pb-0">
                        <div class="listing-short-detail">
                            <h4 class="listing-name">
                                <i class="list-status ti-check"></i>
                                <a href="<?php echo e(route('property',$item->slug)); ?>"><?php echo e($item->title); ?></a>
                            </h4>
                        </div>
                    </div>
                    
                    <div class="price-features-wrapper">
                        <div class="listing-price-fx">
                            <h6 class="listing-card-info-price "><?php echo e($item->price); ?> <?php echo e(config('helper.coin')); ?></h6>
                        </div>
                        <div class="list-fx-features">
                            
                            <?php if($item->propertytype == 'houses' || $item->propertytype == 'apartment' || $item->propertytype == 'villas'): ?>
                            <div class="listing-card-info-icon">
                                <?php if($item->rooms): ?>
                                <span class="inc-fleat inc-bed"><?php echo e($item->rooms); ?> <?php echo e(__('lang.beds')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="listing-card-info-icon">
                                <?php if($item->bathrooms): ?>
                                <span class="inc-fleat inc-bath"><?php echo e($item->bathrooms); ?> <?php echo e(__('lang.bath')); ?></span>
                                <?php endif; ?>
                            </div>
                            <?php else: ?>
                            <div class="listing-card-info-icon">
                                <?php if($item->area): ?>
                                <span class="inc-fleat inc-area"> <?php echo e($item->area); ?>  <?php echo e(__('lang.area')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="listing-card-info-icon">
                                
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>               
        </div>
        
    </div>	
</section>
<?php endif; ?>

<?php if(count($location) > 0): ?>
<section>
    <div class="container">
        
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="sec-heading center">
                    <h2><?php echo e(__('lang.findbylocations')); ?></h2>
                    <p><?php echo e(__('lang.findbylocationsdescription')); ?></p>
                </div>
            </div>
        </div>
        
        <div class="row">
        <?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if($key == 1): ?>
            <div class="col-lg-8 col-md-8">
                <a href="<?php echo e($loc->url); ?>" class="img-wrap">
                        <div class="img-wrap-content visible">
                            <h4><?php echo e($loc->cityname); ?></h4>
                            <span><?php echo e($loc->numberproperty); ?> <?php echo e(__('lang.properties')); ?></span>
                        </div>
                    <div class="img-wrap-background" style="background-image: url(<?php echo e($loc->imagecdn); ?>);"></div>
                </a>	
            </div>
            <?php else: ?>
            
            <div class="col-lg-4 col-md-4">
                <a href="<?php echo e($loc->url); ?>" class="img-wrap">
                        <div class="img-wrap-content visible">
                            <h4><?php echo e($loc->cityname); ?></h4>
                            <span><?php echo e($loc->numberproperty); ?> <?php echo e(__('lang.properties')); ?></span>
                        </div>
                    <div class="img-wrap-background" style="background-image: url(<?php echo e($loc->imagecdn); ?>);"></div>
                </a>
            </div>
            <?php endif; ?>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
        </div>
        
    </div>
</section>
<?php endif; ?>

<?php if(count($blogs) > 0): ?>
<section>
    <div class="container">
    
        <div class="row">
            <div class="col text-center">
                <div class="sec-heading center">
                    <h2><?php echo e(__('lang.trendingarticles')); ?></h2>
                    <p><?php echo e(__('lang.trendingarticlesdescription')); ?></p>
                </div>
            </div>
        </div>
        
        <div class="row">
            
          <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6">
                <div class="blog-wrap-grid">
                    
                    <div class="blog-thumb">
                        <a href="<?php echo e(route('blog',$post->slug)); ?>">
                            <img src="<?php echo e(asset($post->photo)); ?>" class="img-fluid" alt="<?php echo e($post->title); ?>">
                        </a>
                    </div>
                    
                    <div class="blog-info">
                        <span class="post-date"><i class="ti-calendar"></i><?php echo e($post->created_at->diffForHumans()); ?></span>
                    </div>
                    
                    <div class="blog-body">
                        <h4 class="bl-title"><a href="blog-detail.html"><?php echo e($post->title); ?></a></h4>
                        <p><?php echo e(Str::limit($post->excerpt,20)); ?></p>
                        <a href="<?php echo e(route('blog',$post->slug)); ?>" class="bl-continue"><?php echo e(__('lang.continue')); ?></a>
                    </div>
                    
                </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
    </div>		
</section>
<?php endif; ?>

<?php $__env->stopSection(); ?>








<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\imo\resources\views/index.blade.php ENDPATH**/ ?>