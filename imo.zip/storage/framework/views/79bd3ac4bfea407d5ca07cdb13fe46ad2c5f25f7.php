<div wire:ignore.self class="modal fade signup" id="signup" tabindex="-1" role="dialog" aria-labelledby="sign-up" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered login-pop-form" role="document">
        <div class="modal-content" id="sign-up">
            <span class="mod-close" data-dismiss="modal" aria-hidden="true"><i class="ti-close"></i></span>
            <div class="modal-body">
                <h4 class="modal-header-title"><?php echo e(__('lang.sign_up')); ?></h4>
                <div class="login-form">
                    <form wire:submit.prevent="save">
                        
                        <div class="row">
                            
                            <div class="col-lg-6 col-md-6">
                                <div class="form-group">
                                    <div class="input-with-icon">
                                        <input type="text" class="form-control" wire:model.defer="fullname"  placeholder="<?php echo e(__('lang.fullname')); ?>">
                                        <i class="ti-user"></i>
                                    </div>
                                    <p class="text-danger"><?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                </div>
                            </div>
                            
                            <div class="col-lg-6 col-md-6">
                                <div class="form-group">
                                    <div class="input-with-icon">
                                        <input type="email" class="form-control" wire:model.defer="email"  placeholder="<?php echo e(__('lang.email')); ?>">
                                        <i class="ti-email"></i>
                                    </div>
                                    <p class="text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                </div>
                            </div>
                            
                                
                            <div class="col-lg-6 col-md-6">
                                <div class="form-group">
                                    <div class="input-with-icon">
                                        <input type="text" class="form-control" wire:model.defer="phone" placeholder="<?php echo e(__('lang.phone')); ?>">
                                        <i class="lni-phone-handset"></i>
                                    </div>
                                    <p class="text-danger"><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                </div>
                            </div>
                            
                            <div class="col-lg-6 col-md-6">
                                <div class="form-group">
                                    <div class="input-with-icon">
                                        <select wire:model.defer="type"   class="custom-select form-control"  style="color:#868e96;" >
                                            <option value="-1"><?php echo e(__('lang.select_account_type')); ?></option>
                                            <option  value="particulier"><?php echo e(__('lang.particular')); ?></option>
                                            <option   value="professionnel"><?php echo e(__('lang.professional')); ?></option>
                                        </select>
                                        <i class="ti-briefcase"></i>
                                       
                                    </div>
                                    <p class="text-danger"><?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6">
                                <div class="form-group">
                                    <div class="input-with-icon">
                                        <input type="password" wire:model.defer="password" class="form-control" placeholder="<?php echo e(__('lang.password')); ?>" />
                                        <i class="ti-unlock"></i>
                                    </div>
                                </div>
                                <p class="text-danger"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                            </div>
                            <div class="col-lg-6 col-md-6">
                                <div class="form-group">
                                    <div class="input-with-icon">
                                        <input type="password"   wire:model.defer="password_confirmation" class="form-control" placeholder="<?php echo e(__('lang.password_confirmation')); ?>"/>
                                        <i class="ti-unlock"></i>
                                    </div>
                                </div>
                                <p class="text-danger"><?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                            </div>
                            
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" class="btn btn-md full-width pop-login">
                                <?php echo e(__('lang.sign_up')); ?>

                                <span wire:loading wire:target="save">
                                    <div class="spinner-border text-white" role="status">
                                        <span class="visually-hidden"></span>
                                     </div>
                                </span>
                            </button>
                            
                        </div>
                    
                    </form>
                </div>
                <?php if($theme->facebook || $theme->gmail): ?>
                <div class="modal-divider"><span><?php echo e(__('lang.or_login_via')); ?></span></div>
                <?php endif; ?>
                <div class="social-login mb-3">
                    <ul>
                        <?php if($theme->facebook): ?>
                        <li><a href="<?php echo e(route('auth.facebook')); ?>" class="btn connect-fb"><i class="ti-facebook"></i>Facebook</a></li>
                        <?php endif; ?>
                        <?php if($theme->gmail): ?>
                        <li><a href="<?php echo e(route('auth.google')); ?>" class="btn connect-google"><i class="ti-google"></i>Gmail</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
                <div class="text-center">
                    <p class="mt-5"><i class="ti-user mr-1"></i><?php echo e(__('lang.already_have_an_account')); ?> <a href="script:void(0)" id="gologin"  class="link"><?php echo e(__('lang.go_for_login')); ?></a></p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\imo\resources\views/livewire/auth/register.blade.php ENDPATH**/ ?>