[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /home/diabcoog/gif/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>