
<?php $__env->startSection('content'); ?>
<div class="page-title">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                
                <h2 class="ipt-title"><?php echo e($post->title); ?></h2>
                <span class="ipn-subtitle"><?php echo e($post->category->category); ?></span>
                
            </div>
        </div>
    </div>
</div>
<!-- ============================ Page Title End ================================== -->

<!-- ============================ Agency List Start ================================== -->
<section>

    <div class="container">
    
        <!-- row Start -->
        <div class="row">
        
            <!-- Blog Detail -->
            <div class="col-lg-8 col-md-12 col-sm-12 col-12">
                <div class="blog-details single-post-item format-standard">
                    <div class="post-details">
                    
                        <div class="post-featured-img">
                            <img class="img-fluid" src="<?php echo e(asset($post->photo)); ?>" alt="<?php echo e($post->title); ?>">
                        </div>
                        
                        <div class="post-top-meta">
                            <ul class="meta-comment-tag">
                                <li><a href="#"><span class="icons"><i class="ti-user"></i></span><?php echo e(__('lang.by')); ?> <?php echo e(config('app.name')); ?></a></li>
                            </ul>
                        </div>
                        <h2 class="post-title"><?php echo e($post->title); ?></h2>
                        <div>
                            <?php echo $post->content; ?>

                        </div>
                        <div class="post-bottom-meta">
                            <div class="post-tags">
                                <h4 class="pbm-title"><?php echo e(__('lang.relatedtags')); ?></h4>
                                <ul class="list">
                                    <?php if(count($post->tags) > 0): ?>
                                    <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(route('blog.tag',['tag'=>$tag->slug])); ?>"><?php echo e($tag->tag); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </ul>
                            </div>
                            <div class="post-share">
                                <h4 class="pbm-title"><?php echo e(__('lang.socialshare')); ?></h4>
                                <ul class="list">
                                    <li><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(url()->current()); ?>&t=<?php echo e($post->title); ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" target="_blank" title="<?php echo e(__('lang.shareonfacebook')); ?>"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="https://twitter.com/share?url=<?php echo e(url()->current()); ?>&text=<?php echo e($post->title); ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" target="_blank" title="<?php echo e(__('lang.shareontwitter')); ?>"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="whatsapp://send?text=<?php echo e(url()->current()); ?>" data-action="share/whatsapp/share" onClick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" target="_blank" title="<?php echo e(__('lang.shareonwhatsapp')); ?>"><i class="fab fa-whatsapp"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="single-post-pagination">
                            <div class="prev-post">
                                <?php if(!empty($prev)): ?>
                                <a href="<?php echo e(route('blog',['slug'=>$prev->slug])); ?>">
                                    <div class="title-with-link">
                                        <span class="intro"><?php echo e(__('lang.prevpost')); ?></span>
                                        <h3 class="title"><?php echo e(Str::limit($prev->title,15)); ?></h3>
                                    </div>
                                </a>
                                <?php endif; ?>
                            </div>
                            <div class="post-pagination-center-grid">
                                <a href="#"><i class="ti-layout-grid3"></i></a>
                            </div>
                            <div class="next-post">
                                <?php if(!empty($next)): ?>
                                <a href="<?php echo e(route('blog',['slug'=>$next->slug])); ?>">
                                    <div class="title-with-link">
                                        <span class="intro"><?php echo e(__('lang.nextpost')); ?></span>
                                        <h3 class="title"><?php echo e(Str::limit($next->title,15)); ?></h3>
                                    </div>
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                    </div>
                </div>
                
               
                
                
            </div>
            
            <!-- Single blog Grid -->
            <div class="col-lg-4 col-md-12 col-sm-12 col-12">
                
                <!-- Searchbard -->
                <div class="single-widgets widget_search">
                    <h4 class="title"><?php echo e(__('lang.search')); ?></h4>
                    <form action="<?php echo e(route('blog.search')); ?>" class="sidebar-search-form">
                        <input type="search" name="search" placeholder="<?php echo e(__('lang.search')); ?>..">
                        <button type="submit"><i class="ti-search"></i></button>
                    </form>
                </div>

                <!-- Categories -->
                <div class="single-widgets widget_category">
                    <h4 class="title"><?php echo e(__('lang.categories')); ?></h4>
                    <ul>
                        <?php if(count($categories) > 0): ?>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('blogs',['category'=>$category->slug])); ?>"><?php echo e($category->category); ?> <span><?php echo e(count($category->posts)); ?></span></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </ul>
                </div>
                
                <!-- Trending Posts -->
                <div class="single-widgets widget_thumb_post">
                    <h4 class="title"><?php echo e(__('lang.trendingposts')); ?></h4>
                    <ul>
                        <?php if(count($posts) > 0): ?>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <span class="left">
                                <img src="<?php echo e(asset($post->photo)); ?>" alt="$post->title">
                            </span>
                            <span class="right">
                                <a class="feed-title" href="<?php echo e(route('blog',['slug'=>$post->slug])); ?>"><?php echo e(Str::limit($post->title,25)); ?></a> 
                                <span class="post-date"><i class="ti-calendar"></i><?php echo e($post->created_at->diffForHumans()); ?></span>
                            </span>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </ul>
                </div>
                
                <!-- Tags Cloud -->
                <div class="single-widgets widget_tags">
                    <h4 class="title"><?php echo e(__('lang.tagscloud')); ?></h4>
                    <ul>
                        <?php if(count($tags) > 0): ?>
                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <li><a href="<?php echo e(route('blog.tag',['tag'=>$tag->slug])); ?>"><?php echo e($tag->tag); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </ul>
                </div>
                
            </div>
            
        </div>
        <!-- /row -->					
        
    </div>
            
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/diabcoog/gif/resources/views/frontblog/index.blade.php ENDPATH**/ ?>