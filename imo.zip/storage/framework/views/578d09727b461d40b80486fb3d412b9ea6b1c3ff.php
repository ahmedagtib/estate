<section>
<div class="container">
    <div class="row">
         <div class="col-md-6 mx-auto">
             <h2 class="text-center"><?php echo e(__('lang.forgot_your_password')); ?></h2>
             <h3 class="text-center mt-2 text-success"><?php echo e($success_forgot_message); ?></h3>
             <h3 class="text-center mt-2  text-danger"><?php echo e($error_forgot_message); ?></h3>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <h3 class="text-center mt-2  text-danger"><?php echo e($message); ?></h3>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="form-group">
                <div class="input-with-icon">
                    <input  type="email" wire:model="email" class="form-control" placeholder="<?php echo e(__('lang.email')); ?>">
                    <i class="ti-email"></i>
                </div>
            </div>
            <div class="form-group">
                <button wire:click="sendmail" class="btn btn-theme-2 btn-block"><?php echo e(__('lang.send')); ?></button>
            </div>

         </div>
    </div>
</div>
</section>

<?php /**PATH /home/diabcoog/gif/resources/views/livewire/auth/forgot-password.blade.php ENDPATH**/ ?>