<div>
    <div class="page-title">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    
                    <h2 class="ipt-title"><?php echo e(__('lang.welcome')); ?></h2>
                    <span class="ipn-subtitle"><?php echo e(__('lang.welcome_to_your_account')); ?></span>
                    <?php if(Auth::user()->email_verified_at == null): ?>
                         <div class="alert alert-warning mt-4">
                                <?php echo e(__('lang.account_not_verified')); ?> - <a class="text-warning" href="<?php echo e(route('email.verify')); ?>"><?php echo e(__('lang.click')); ?></a>
                         </div>
                    <?php endif; ?>                    
                </div>
            </div>
        </div>
    </div>
    
    <section>
        <div class="container">
            <div class="row">
                 <?php echo $__env->make('account.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-lg-8 col-md-12">
                    <div class="dashboard-wraper">
                    
                        <!-- Basic Information -->
                        <div class="form-submit">	
                            <h4><?php echo e(__('lang.pendingpropetites')); ?></h4>
                            <div class="submit-section">
                                <div>
                                    <button class="btn btn-success" wire:click="change"><?php echo e(__('lang.makeselectedchamp')); ?></button>
                                    <p class="text-danger"><?php $__errorArgs = ['array'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                </div>
                                <?php if(count($properties) > 0): ?>
                                <table class="table table-striped">
                                    <thead>
                                      <tr>
                                        <th scope="col">#</th>
                                        <th scope="col"><?php echo e(__('lang.property')); ?></th>
                                        <th scope="col"><?php echo e(__('lang.show')); ?></th>
                                        <th scope="col"><?php echo e(__('lang.accepted')); ?></th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                     <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <tr>
                                        <th scope="row"><?php echo e($item->id); ?></th>
                                        <td><?php echo e($item->title); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('property',$item->slug)); ?>">
                                                <i class="ti-pencil"></i>
                                            </a>
                                        </td>
                                        <td>
                                            <input wire:model="array" type="checkbox"  value="<?php echo e($item->id); ?>" />
                                        </td>
                                      </tr>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </tbody>
                                </table>
                                <?php endif; ?>
                            </div>
                        </div>
                     </div>
                   </div>
                        
                    </div>
                </div>
                
            </div>
        </div>
    </section>
</div>


<?php /**PATH /home/diabcoog/gif/resources/views/livewire/admin/pendding-propety.blade.php ENDPATH**/ ?>