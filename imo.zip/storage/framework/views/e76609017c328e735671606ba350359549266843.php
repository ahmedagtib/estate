<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<?php if(trim($slot) === 'Laravel'): ?>
<img src="<?php echo e(asset('images/logo/logo.jpg')); ?>" class="logo" alt="<?php echo e(config('app.name')); ?>">
<?php else: ?>
<?php echo e($slot); ?>

<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH C:\xampp\htdocs\imo\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>