
<?php $__env->startSection('content'); ?>
<div class="page-title">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <?php if($option == 'blog'): ?>
                <h2 class="ipt-title"><?php echo e(__('lang.ourarticles')); ?></h2>
                <span class="ipn-subtitle"><?php echo e(__('lang.blogdescription')); ?></span>
                <?php endif; ?>
                <?php if($option == 'tag'): ?>
                <h2 class="ipt-title"><?php echo e($title); ?></h2>
                <span class="ipn-subtitle"><?php echo e(__('lang.latesttag',['tag'=>$title])); ?></span>
                <?php endif; ?>
                <?php if($option == 'category'): ?>
                <h2 class="ipt-title"><?php echo e($title); ?></h2>
                <?php endif; ?>
                <?php if($option == 'search'): ?>
                <h2 class="ipt-title"><?php echo e(__('lang.yoursearch',['search'=>$title])); ?></h2>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<section>

    <div class="container">
        <?php if(count($data) > 0): ?>
            
        <div class="row">
             <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6">
                <div class="blog-wrap-grid">
                    
                    <div class="blog-thumb">
                        <a href="<?php echo e(route('blog',['slug'=>$d->slug])); ?>"><img src="<?php echo e(asset($d->photo)); ?>" class="img-fluid" alt="<?php echo e($d->title); ?>" /></a>
                    </div>
                    
                    <div class="blog-info">
                        <span class="post-date"><i class="ti-calendar"></i><?php echo e($d->created_at->diffForHumans()); ?></span>
                    </div>
                    
                    <div class="blog-body">
                        <h4 class="bl-title"><a href="<?php echo e(route('blog',['slug'=>$d->slug])); ?>"><?php echo e($d->title); ?></a></h4>
                        <p><?php echo e(Str::limit($d->excerpt,30)); ?></p>
                        <a href="<?php echo e(route('blog',['slug'=>$d->slug])); ?>" class="bl-continue"><?php echo e(__('lang.continue')); ?></a>
                    </div>
                    
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

           
                  
        </div>
        <!-- /row -->

        <!-- Pagination -->
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <ul class="pagination p-center">
                    <?php echo e($data->links()); ?>

                </ul>
            </div>
        </div>					
        <?php endif; ?>
    </div>
            
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\imo\resources\views/frontblog/blog.blade.php ENDPATH**/ ?>