
<?php $__env->startSection('content'); ?>
<div class="page-title">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                
                <h2 class="ipt-title"><?php echo e($title); ?></h2> 
            </div>
        </div>
    </div>
</div>
<section>
    <div class="container">
    
        <div class="row">
            <div class="col-md-12 col-sm-12">
                <h4><?php echo e(__('lang.totalpropertyfindis')); ?>: <span class="theme-cl"><?php echo e($count); ?></span></h4>
            </div>
        </div>
    
        <div class="row">
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="property-listing property-2">
                    <div class="listing-img-wrapper">
                        <div class="list-img-slide">
                            <div class="click">
                                <?php $__currentLoopData = $property->thumbnails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!empty($photo)): ?>
                                <div>
                                    <a  href="<?php echo e(route('property',['slug'=>$property->slug])); ?>">
                                        <img  src="<?php echo e(asset($photo)); ?>" class="img-fluid mx-auto" alt="<?php echo e($property->title); ?>" title="<?php echo e($property->title); ?>" />
                                    </a>
                                </div>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <span class="property-type">
                           <?php if($property->status == 'rent'): ?> <?php echo e(__('lang.forrent')); ?> <?php endif; ?>
                           <?php if($property->status == 'sale'): ?> <?php echo e(__('lang.forsale')); ?> <?php endif; ?>
                        </span>
                    </div>
                    
                    <div class="listing-detail-wrapper pb-0">
                        <div class="listing-short-detail">
                            <h4 class="listing-name">
                                <a href="<?php echo e(route('property',['slug'=>$property->slug])); ?>"><?php echo e($property->title); ?></a>
                                <i class="list-status ti-check"></i></h4>
                        </div>
                    </div>
                    
                    <div class="price-features-wrapper">
                        <div class="listing-price-fx">
                            <h6 class="listing-card-info-price"><?php echo e($property->price); ?><span><?php echo e(config('helper.coin')); ?></span></h6>
                        </div>
                        <div class="list-fx-features">
                            <?php if($property->propertytype == 'houses' || $property->propertytype == 'apartment' || $property->propertytype == 'villas'): ?>
                            <div class="listing-card-info-icon">
                                <?php if($property->bedrooms): ?>
                                <span class="inc-fleat inc-bed"><?php echo e($property->bedrooms); ?> <?php echo e(__('lang.beds')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="listing-card-info-icon">
                                <?php if($property->bathrooms): ?>
                                <span class="inc-fleat inc-bath"><?php echo e($property->bathrooms); ?>  <?php echo e(__('lang.bath')); ?></span>
                                <?php endif; ?>
                            </div>
                            <?php else: ?> 
                            <div class="listing-card-info-icon">
                                <?php if($property->area): ?>
                                <span class="inc-fleat inc-area"><?php echo e($property->area); ?>  <?php echo e(__('lang.area')); ?></span>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>          
        </div>
        
        <!-- Pagination -->
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <ul class="pagination p-center">
                    <?php echo e($data->links()); ?>

                     
                </ul>
            </div>
        </div>
        
    </div>		
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\imo\resources\views/search.blade.php ENDPATH**/ ?>