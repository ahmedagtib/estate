<div>
    <div class="page-title">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    
                    <h2 class="ipt-title"><?php echo e(__('lang.welcome')); ?></h2>
                    <span class="ipn-subtitle"><?php echo e(__('lang.welcome_to_your_account')); ?></span>
                    <?php if(Auth::user()->email_verified_at == null): ?>
                         <div class="alert alert-warning mt-4">
                                <?php echo e(__('lang.account_not_verified')); ?> - <a class="text-warning" href="<?php echo e(route('email.verify')); ?>"><?php echo e(__('lang.click')); ?></a>
                         </div>
                    <?php endif; ?>                    
                </div>
            </div>
        </div>
    </div>
    <section>
        <div class="container">
            <div class="row">
                 <?php echo $__env->make('account.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-lg-8 col-md-12">
                    <div class="dashboard-wraper">
                        <div class="form-submit">	
                            <h4><?php echo e(__('lang.createnewpage')); ?></h4>
                            <div class="submit-section">
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label><?php echo e(__('lang.pagetitle')); ?></label>
                                        <input wire:model="title" type="text" class="form-control">
                                        <p class="text-danger"><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    </div>
                                    <div class="form-group col-md-12">
                                        <label><?php echo e(__('lang.pagephoto')); ?></label>
                                        <input type="file"  wire:model="image" class="form-control">
                                        <p class="text-danger"><?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    </div>
                                    <div class="form-group col-md-12">
                                        <label><?php echo e(__('lang.excerpt')); ?></label>
                                        <textarea wire:model="excerpt" class="form-control"></textarea>
                                    </div>
                                    <div wire:ignore class="form-group col-md-12">
                                        <label><?php echo e(__('lang.pagecontent')); ?></label>
                                        <input type="hidden"  id="content" value="<?php echo e($content); ?>" />
                                        <trix-editor  
                                           class="trix-content"
                                           input="content"  
                                           ></trix-editor>
                                    </div>
                                    <p class="text-danger"><?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    <div class="form-group col-md-12">
                                        <label><?php echo e(__('lang.metatitle')); ?></label>
                                        <input type="text" wire:model="meta_title" class="form-control">
                                        <p class="text-danger"><?php $__errorArgs = ['meta_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    </div>
                                    <div class="form-group col-md-12">
                                        <label><?php echo e(__('lang.metacontent')); ?></label>
                                        <textarea wire:model="meta_content" class="form-control"></textarea>
                                        <p class="text-danger"><?php $__errorArgs = ['meta_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    </div>
                                    <div  class="form-group col-md-12">
                                        <label><?php echo e(__('lang.metakeyword')); ?></label>
                                        <input type="text" class="form-control" wire:model="meta_keyword"  value="<?php echo e($meta_keyword); ?>" placeholder="<?php echo e(__('lang.example')); ?><?php echo e(__('lang.exmpletag')); ?>">
                                    </div>
                                    <p class="text-danger"><?php $__errorArgs = ['meta_keyword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    <div class="form-group col-md-12">
                                        <button wire:click="save" class="btn btn-theme" type="submit"><?php echo e(__('lang.send')); ?></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</div>

<script src="<?php echo e(asset('js/trix.js')); ?>"></script>

<script>
    var content = document.getElementById("content")
    addEventListener("trix-change", function(event) {
        window.livewire.find('<?php echo e($_instance->id); ?>').set('content', content.getAttribute('value'))
    });

</script>
<?php /**PATH /home/diabcoog/gif/resources/views/livewire/admin/pages-create.blade.php ENDPATH**/ ?>