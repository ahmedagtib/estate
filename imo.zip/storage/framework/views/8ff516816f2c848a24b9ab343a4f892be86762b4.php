<div>
    <div class="page-title">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    
                    <h2 class="ipt-title"><?php echo e(__('lang.welcome')); ?></h2>
                    <span class="ipn-subtitle"><?php echo e(__('lang.welcome_to_your_account')); ?></span>
                    <?php if(Auth::user()->email_verified_at == null): ?>
                         <div class="alert alert-warning mt-4">
                                <?php echo e(__('lang.account_not_verified')); ?> - <a class="text-warning" href="<?php echo e(route('email.verify')); ?>"><?php echo e(__('lang.click')); ?></a>
                         </div>
                    <?php endif; ?>                    
                </div>
            </div>
        </div>
    </div>
    <section>
        <div class="container">
           <div class="row">
              <?php echo $__env->make('account.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <div class="col-lg-8 col-md-12">
                 <div class="dashboard-wraper">
                    <div class="form-submit">
                    <div class="form-row">
                          <h4><?php echo e(__('lang.createblog')); ?></h4>
        
                        <div class="form-group col-md-12">
                            <label ><?php echo e(__('lang.titleblog')); ?></label>
                            <input type="text" wire:model="title" class="form-control"  placeholder="<?php echo e(__('lang.titleblog')); ?>">
                            <p class="text-danger"><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                        </div>
                        <div class="form-group col-md-12">
                            <label ><?php echo e(__('lang.selectcategory')); ?></label>
                            <select wire:model="category_id" class="form-control custom-select">
                                 <?php if(count($categories) > 0): ?>
                                      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($category->id); ?>"><?php echo e($category->category); ?></option> 
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 <?php endif; ?>
                            </select>
                            <p class="text-danger"><?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                        </div>
                        <div class="form-group col-md-12">
                            <label ><?php echo e(__('lang.blogphoto')); ?></label>
                            <input type="file" wire:model="photo" class="form-control"  placeholder="<?php echo e(__('lang.blogphoto')); ?>">
                            <p class="text-danger"><?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                        </div>
                        <div class="form-group col-md-12">
                            <label ><?php echo e(__('lang.blogexcerpt')); ?></label>
                            <textarea wire:model="excerpt" class="form-control"></textarea>
                            <p class="text-danger"><?php $__errorArgs = ['excerpt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                        </div>
                        <div wire:ignore class="form-group col-md-12">
                            <label ><?php echo e(__('lang.blogcontent')); ?></label>
                            <input type="hidden"  id="content" value="<?php echo e($content); ?>" />
                            <trix-editor  
                            class="trix-content"
                            input="content"  
                            ></trix-editor>
                        </div>
                        <p class="text-danger"><?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                        <div class="form-group col-md-12">
                            <label ><?php echo e(__('lang.metatitle')); ?></label>
                            <textarea wire:model="meta_title" class="form-control"></textarea>
                            <p class="text-danger"><?php $__errorArgs = ['meta_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                        </div>
                        <div class="form-group col-md-12">
                            <label ><?php echo e(__('lang.metacontent')); ?></label>
                            <textarea wire:model="meta_description" class="form-control"></textarea>
                            <p class="text-danger"><?php $__errorArgs = ['meta_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                        </div>
                        <div class="form-group col-md-12">
                            <label ><?php echo e(__('lang.metakeyword')); ?></label>
                            <textarea wire:model="meta_keyword" class="form-control" placeholder="<?php echo e(__('lang.example')); ?><?php echo e(__('lang.exmpletag')); ?>"></textarea>
                            <p class="text-danger"><?php $__errorArgs = ['meta_keyword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                        </div>
                        <div class="form-group col-md-12">
                            <label><?php echo e(__('lang.selectstatus')); ?></label>
                            <select wire:model="statue" class="form-control custom-select">
                               <option value="pending"><?php echo e(__('lang.pending')); ?></option>
                                <option value="publiched"><?php echo e(__('lang.published')); ?></option>
                            </select>
                            <p class="text-danger"><?php $__errorArgs = ['statue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                        </div>
                        <div  class="form-group col-md-12">
                            <label><?php echo e(__('lang.tag')); ?></label>
                            <input type="text" class="form-control" wire:model="tag"  value="<?php echo e($tag); ?>" placeholder="<?php echo e(__('lang.example')); ?><?php echo e(__('lang.exmpletag')); ?>">
                        </div>
                        <p class="text-danger"><?php $__errorArgs = ['tag'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                        <div class="form-group col-md-12">
                            <button wire:click="save" class="btn btn-theme" type="submit"><?php echo e(__('lang.send')); ?></button>
                        </div>
                    </div>
                    </div>
                 </div>
              </div>
           </div>
        </div>
        </div>
     </section>    

</div>
<script src="<?php echo e(asset('js/trix.js')); ?>"></script>

<script>
    var content = document.getElementById("content")
    addEventListener("trix-change", function(event) {
        console.log(content);
        window.livewire.find('<?php echo e($_instance->id); ?>').set('content', content.getAttribute('value'))
    });

</script>



<?php /**PATH /home/diabcoog/gif/resources/views/livewire/admin/create-blog.blade.php ENDPATH**/ ?>