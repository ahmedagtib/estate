	<!-- ============================ Footer Start ================================== -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('footer')->html();
} elseif ($_instance->childHasBeenRendered('PrYxjsO')) {
    $componentId = $_instance->getRenderedChildComponentId('PrYxjsO');
    $componentTag = $_instance->getRenderedChildComponentTagName('PrYxjsO');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('PrYxjsO');
} else {
    $response = \Livewire\Livewire::mount('footer');
    $html = $response->html();
    $_instance->logRenderedChild('PrYxjsO', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <!-- ============================ Footer End ================================== -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('login')->html();
} elseif ($_instance->childHasBeenRendered('T3GY3iu')) {
    $componentId = $_instance->getRenderedChildComponentId('T3GY3iu');
    $componentTag = $_instance->getRenderedChildComponentTagName('T3GY3iu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('T3GY3iu');
} else {
    $response = \Livewire\Livewire::mount('login');
    $html = $response->html();
    $_instance->logRenderedChild('T3GY3iu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('register')->html();
} elseif ($_instance->childHasBeenRendered('T64u7Xs')) {
    $componentId = $_instance->getRenderedChildComponentId('T64u7Xs');
    $componentTag = $_instance->getRenderedChildComponentTagName('T64u7Xs');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('T64u7Xs');
} else {
    $response = \Livewire\Livewire::mount('register');
    $html = $response->html();
    $_instance->logRenderedChild('T64u7Xs', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp\htdocs\imo\resources\views/layouts/footer.blade.php ENDPATH**/ ?>