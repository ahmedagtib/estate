<?php echo e($slot); ?>

<?php /**PATH /home/diabcoog/gif/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>