<div>
    <div class="page-title">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    
                    <h2 class="ipt-title"><?php echo e(__('lang.welcome')); ?></h2>
                    <span class="ipn-subtitle"><?php echo e(__('lang.welcome_to_your_account')); ?></span>
                    <?php if(Auth::user()->email_verified_at == null): ?>
                         <div class="alert alert-warning mt-4">
                                <?php echo e(__('lang.account_not_verified')); ?> - <a class="text-warning" href="<?php echo e(route('email.verify')); ?>"><?php echo e(__('lang.click')); ?></a>
                         </div>
                    <?php endif; ?>                    
                </div>
            </div>
        </div>
    </div>
    
    <section>
        <div class="container">
            <div class="row">
                 <?php echo $__env->make('account.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-lg-8 col-md-12">
                    <div class="dashboard-wraper">
                        <div class="form-submit">	
                            <h4><?php echo e(__('lang.managecategories')); ?></h4>
                            <div class="form-check">
                                <input class="checkbox-custom" wire:model.defer="gmail" name="gmail" type="checkbox"  id="gmail" <?php if($gmail == 1): ?> checked <?php endif; ?>>
                                <label class="checkbox-custom-label" for="gmail">
                                 <?php echo e(__('lang.gmailauth')); ?>

                            </div>
                            <div class="form-check">
                                <input class="checkbox-custom" wire:model.defer="facebook" type="checkbox"  name="facebook" id="facebook" <?php if($facebook == 1): ?> checked <?php endif; ?>>
                                <label class="checkbox-custom-label" for="facebook">
                                 <?php echo e(__('lang.facebookauth')); ?>

                            </div>
                            <div class="form-group">
                                <h6><?php echo e(__('lang.property')); ?> style</h6>
                                <div class="form-check">
                                    <input class="radio-custom" wire:model.defer="propertypage" name="propertypage"  type="radio" value="1" id="propertyone">
                                    <label class="radio-custom-label" for="propertyone">
                                     <?php echo e(__('lang.property')); ?> - 1
                                </div>
                                <div class="form-check">
                                    <input class="radio-custom" wire:model.defer="propertypage" name="propertypage" type="radio" value="2" id="propertytow">
                                    <label class="radio-custom-label" for="propertytow">
                                     <?php echo e(__('lang.property')); ?> - 2
                                </div>
                                <div class="form-check">
                                    <input class="radio-custom" wire:model.defer="propertypage" name="propertypage" type="radio" value="3" id="propertythere">
                                    <label class="radio-custom-label" for="propertythere">
                                     <?php echo e(__('lang.property')); ?>  - 3
                                </div>
                            </div>
                            <div class="form-group">
                                <h6><?php echo e(__('lang.home')); ?> style</h6>
                                <div class="form-check">
                                    <input class="radio-custom" wire:model.defer="homepage" name="homepage" type="radio" value="1" id="homeone">
                                    <label class="radio-custom-label" for="homeone">
                                     <?php echo e(__('lang.home')); ?> - 1
                                </div>
                                <div class="form-check">
                                    <input class="radio-custom" wire:model.defer="homepage" name="homepage" type="radio" value="2" id="hometow">
                                    <label class="radio-custom-label" for="hometow">
                                     <?php echo e(__('lang.home')); ?> - 2
                                </div>
                                <div>
                                    <button wire:click="send()" class="btn btn-success"><?php echo e(__('lang.update')); ?></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php /**PATH /home/diabcoog/gif/resources/views/livewire/admin/theme-custom.blade.php ENDPATH**/ ?>