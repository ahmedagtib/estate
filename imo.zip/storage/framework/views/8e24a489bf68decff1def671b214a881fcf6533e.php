<div>
    <div class="page-title">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    
                    <h2 class="ipt-title"><?php echo e(__('lang.welcome')); ?></h2>
                    <span class="ipn-subtitle"><?php echo e(__('lang.welcome_to_your_account')); ?></span>
                    <?php if(Auth::user()->email_verified_at == null): ?>
                         <div class="alert alert-warning mt-4">
                                <?php echo e(__('lang.account_not_verified')); ?> - <a class="text-warning" href="<?php echo e(route('email.verify')); ?>"><?php echo e(__('lang.click')); ?></a>
                         </div>
                    <?php endif; ?>
                    <?php if(Session::has('success')): ?>
                      <div class="alert alert-success mt-4">
                           <?php echo e(session::get('success')); ?> 
                      </div>
                    <?php endif; ?>
                    <?php if(Session::has('error')): ?>
                      <div class="alert alert-danger mt-4">
                           <?php echo e(session::get('error')); ?> 
                      </div>
                    <?php endif; ?>
                    
                </div>
            </div>
        </div>
    </div>
    <section>
        <div class="container">
            <div class="row">
                 <?php echo $__env->make('account.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                 <div class="col-lg-8 col-md-12">
                    <div class="dashboard-wraper">
                    
                        <!-- Bookmark Property -->
                        <div class="form-submit">
                            <div class="d-flex justify-content-between">
                                <h4><?php echo e(__('lang.myproperty')); ?></h4>
                                <a href="<?php echo e(route('create.property')); ?>" class="btn btn-primary text-white"><?php echo e(__('lang.newproperty')); ?></a>
                            </div>	
                           
                        </div>
                        
                        <table class="mt-2 property-table-wrap responsive-table">

                            <tbody>
                                <tr>
                                    <th><i class="fa fa-file-text"></i> <?php echo e(__('lang.property')); ?></th>
                                    <th class="expire-date"><i class="fa fa-calendar"></i> <?php echo e(__('lang.poststatus')); ?></th>
                                    <th></th>
                                </tr>
                                <?php if(count($properties) > 0): ?>
                                  <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                    <td class="property-container">
                                        <img width="50"  height="80" src="<?php echo e(asset($property->image)); ?>" alt="">
                                        <div class="title">
                                            <h4><a href="#"><?php echo e($property->title); ?></a></h4>
                                            <span><?php echo e($property->adress); ?></span>
                                            <span class="table-property-price">$<?php echo e($property->price); ?></span>
                                        </div>
                                    </td>
                                    <td class="expire-date">
                                        <?php if($property->poststatus == 'pending'): ?>
                                        <span class="badge badge-warning"><?php echo e(__('lang.pending')); ?></span>
                                        <?php endif; ?>
                                        <?php if($property->poststatus == 'published'): ?>
                                         <span class="badge badge-success"><?php echo e(__('lang.published')); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="action">
                                        <a href="<?php echo e(route('update.property',['slug'=>$property->slug])); ?>"><i class="ti-pencil"></i> <?php echo e(__('lang.edit')); ?></a>
                                        <a href="<?php echo e(route('property',['slug'=>$property->slug])); ?>"><i class="ti-eye"></i> <?php echo e(__('lang.show')); ?></a>
                                        <a href="#" wire:click="removeProperty('<?php echo e($property->slug); ?>')" class="delete"><i class="ti-close"></i> <?php echo e(__('lang.delete')); ?></a>
                                    </td>
                                </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <div class="mt-1">
                            <?php echo e($properties->links()); ?>

                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </section>
</div>
<?php /**PATH /home/diabcoog/gif/resources/views/livewire/user/list-property.blade.php ENDPATH**/ ?>