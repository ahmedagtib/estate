<div class="col-lg-4 col-md-12">
    <div class="dashboard-navbar">
        
        <div class="d-user-avater">
            <?php if(empty(auth()->user()->avatar)): ?>
            <img src="<?php echo e(asset('images/avatar/default.jpg')); ?>" class="img-fluid avater" alt="<?php echo e(auth()->user()->fullname); ?>">
            <?php else: ?> 
            <img src="<?php echo e(asset(auth()->user()->avatar)); ?>" class="img-fluid avater" alt="<?php echo e(auth()->user()->fullname); ?>">
            <?php endif; ?>

            <h4><?php echo e(auth()->user()->fullname); ?></h4>
            <?php if(empty(auth()->user()->email_verified_at)): ?>
              <span class="text-danger"><?php echo e(__('lang.account_unverified')); ?></span>
            <?php else: ?> 
              <span class="text-success"><?php echo e(__('lang.account_verified')); ?></span>   
            <?php endif; ?>
           
        </div>
        
        <div class="d-navigation">
            <ul>
                <li class="<?php echo e(Request::routeIs('profile') ? 'active' : ''); ?>"><a href="<?php echo e(route('profile')); ?>"><i class="ti-user"></i><?php echo e(__('lang.myprofile')); ?></a></li>
                <li class="<?php echo e(Request::routeIs('update.password') ? 'active' : ''); ?>"><a href="<?php echo e(route('update.password')); ?>"><i class="ti-unlock"></i><?php echo e(__('lang.updatepassword')); ?></a></li>
                <li class="<?php echo e(Request::routeIs('myproperty') ? 'active' : ''); ?>"><a href="<?php echo e(route('myproperty')); ?>"><i class="ti-layers"></i><?php echo e(__('lang.myproperty')); ?></a></li>
                <li class="<?php echo e(Request::routeIs('create.property') ? 'active' : ''); ?>"><a href="<?php echo e(route('create.property')); ?>"><i class="ti-pencil-alt"></i><?php echo e(__('lang.submitnewproperty')); ?></a></li>
                <?php if(Auth::user()->hasRole('admin')): ?>
                <li class="<?php echo e(Request::routeIs('state') ? 'active' : ''); ?>"><a href="<?php echo e(route('state')); ?>"><i class="ti-map"></i><?php echo e(__('lang.managestate')); ?></a></li>
                <li class="<?php echo e(Request::routeIs('city') ? 'active' : ''); ?>"><a href="<?php echo e(route('city')); ?>"><i class="ti-location-pin"></i><?php echo e(__('lang.managecities')); ?></a></li>
                <li class="<?php echo e(Request::routeIs('page') ? 'active' : ''); ?>"><a href="<?php echo e(route('page')); ?>"><i class="ti-file"></i><?php echo e(__('lang.managepages')); ?></a></li>
                <li class="<?php echo e(Request::routeIs('category') ? 'active' : ''); ?>"><a href="<?php echo e(route('category')); ?>"><i class="ti-widgetized"></i><?php echo e(__('lang.category')); ?></a></li>
                <li class="<?php echo e(Request::routeIs('tag') ? 'active' : ''); ?>"><a href="<?php echo e(route('tag')); ?>"><i class="ti-widgetized"></i><?php echo e(__('lang.tag')); ?></a></li>
                <li class="<?php echo e(Request::routeIs('tag') ? 'active' : ''); ?>"><a href="<?php echo e(route('blog.manage')); ?>"><i class="ti-widgetized"></i><?php echo e(__('lang.blogmanage')); ?></a></li>
                <li class="<?php echo e(Request::routeIs('findbylocation') ? 'active' : ''); ?>"><a href="<?php echo e(route('findbylocation')); ?>"><i class="ti-map-alt"></i><?php echo e(__('lang.findbylocation')); ?></a></li>
                <li class="<?php echo e(Request::routeIs('pending.property') ? 'active' : ''); ?>"><a href="<?php echo e(route('pending.property')); ?>"><i class="ti-pencil"></i><?php echo e(__('lang.pendingpropetites')); ?></a></li>
                <li class="<?php echo e(Request::routeIs('theme') ? 'active' : ''); ?>"><a href="<?php echo e(route('theme')); ?>"><i class="ti-settings"></i><?php echo e(__('lang.customtheme')); ?></a></li>
                <li class="<?php echo e(Request::routeIs('setting.manage') ? 'active' : ''); ?>"><a href="<?php echo e(route('setting.manage')); ?>"><i class="ti-settings"></i><?php echo e(__('lang.setting')); ?></a></li>
                <?php endif; ?>
                <li class="<?php echo e(Request::routeIs('logout') ? 'active' : ''); ?>"><a href="<?php echo e(route('logout')); ?>"><i class="ti-power-off"></i><?php echo e(__('lang.logout')); ?></a></li>
            </ul>
        </div>
        
    </div>
</div><?php /**PATH /home/diabcoog/gif/resources/views/account/sidebar.blade.php ENDPATH**/ ?>