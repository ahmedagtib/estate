
<?php $__env->startSection('meta'); ?>
<meta property="og:url"                content="<?php echo e(url()->current()); ?>" />
<meta property="og:type"               content="article" />
<meta property="og:title"              content="<?php echo e($property->title); ?>" />
<meta property="og:description"        content="<?php echo e($property->title); ?> - <?php echo e(Config('app.name')); ?>" />
<meta property="og:image"              content="<?php echo e(asset($property->photos[0])  ??  ''); ?>" />
<meta name="twitter:card" content="summary" />
<meta name="twitter:site" content="<?php echo e(Config('app.name')); ?>" />
<meta name="twitter:creator" content="<?php echo e(Config('app.name')); ?>" />
<meta property="og:url" content="<?php echo e(url()->current()); ?>" />
<meta property="og:title" content="<?php echo e($property->title); ?>" />
<meta property="og:description" content="<?php echo e($property->title); ?> - <?php echo e(Config('app.name')); ?>" />
<meta property="og:image" content="<?php echo e(asset($property->photos[0])  ??  ''); ?>" />
<style>
    @media(max-width: 576px) { 
  .property-statement ul li{
      width: 65% !important;
  }    
}

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if($theme == 1): ?>
<div class="featured-slick">
    <div class="featured-slick-slide">
        <?php if(isset($property->photos)   && count($property->photos) > 0): ?>
        <?php $__currentLoopData = $property->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div><a href="<?php echo e(asset($photo)); ?>" class="mfp-gallery"><img src="<?php echo e(asset($photo)); ?>" class="img-fluid mx-auto" alt="<?php echo e($property->title); ?>" /></a></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?> 
        <div><a href="<?php echo e(asset('images\property\default.jpg')); ?>" class="mfp-gallery"><img src="<?php echo e(asset('images\property\default.jpg')); ?>" class="img-fluid mx-auto" alt="<?php echo e($property->title); ?>" /></a></div>
        <?php endif; ?>
    </div>
</div>
<section class="spd-wrap">
    <div class="container">
        <div class="row">
            
            <div class="col-lg-12 col-md-12">
                <div class="slide-property-detail">
                    <div class="slide-property-first">
                        <h1 class="title"><?php echo e($property->title); ?></h1>
                        <div class="pr-price-into">
                            <h2><?php echo e(config('helper.coin')); ?> <?php echo e($property->price); ?> 
                             <?php if($property->status == 'sale'): ?>   <span class="prt-type sale"><?php echo e(__('lang.forsale')); ?></span> <?php endif; ?>
                             <?php if($property->status == 'rent'): ?>   <span class="prt-type rent"><?php echo e(__('lang.forrent')); ?></span> <?php endif; ?>
                            </h2>
                            <span><i class="lni-map-marker"></i> <?php echo e($property->address); ?></span>
                        </div>
                        
                    </div>
                    
                    <div class="slide-property-sec">
                        <div class="pr-all-info">
                            
                            <div class="pr-single-info">
                                <div class="share-opt-wrap">
                                    <button type="button" class="btn-share" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-original-title="Share this">
                                        <i class="lni-share"></i>
                                    </button>
                                    <div class="dropdown-menu animated flipInX">
                                        <a  href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(url()->current()); ?>&t=<?php echo e($property->title); ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" target="_blank" title="<?php echo e(__('lang.shareonfacebook')); ?>"  class="cl-facebook"><i class="lni-facebook"></i></a>
                                        <a href="https://twitter.com/share?url=<?php echo e(url()->current()); ?>&text=<?php echo e($property->title); ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" target="_blank" title="<?php echo e(__('lang.shareontwitter')); ?>" class="cl-twitter"><i class="lni-twitter"></i></a>
                                        <a href="whatsapp://send?text=<?php echo e(url()->current()); ?>" data-action="share/whatsapp/share" onClick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" target="_blank" title="<?php echo e(__('lang.shareonwhatsapp')); ?>" class="cl-whatsapp"><i class="lni-whatsapp"></i></a>
                                        
                                    </div>
                                </div>

                            </div>
                            
                            <div class="pr-single-info">
                                <a href="<?php echo e(route('property.pdf',$property->slug)); ?>" data-toggle="tooltip" data-original-title="Get Print"><i class="ti-printer"></i></a>
                            </div>
                            
                          
                        </div>
                    </div>
                    
                </div>
                
            </div>
        </div>
    </div>
</section>
<section class="gray">
    <div class="container">
        <div class="row">
            
            <!-- property main detail -->
            <div class="col-lg-8 col-md-12 col-sm-12">
                
                <!-- Single Block Wrap -->
                <div class="block-wrap">
                    
                    <div class="block-header">
                        <h4 class="block-title"><?php echo e(__('lang.propertyinfo')); ?></h4>
                    </div>
                    
                    <div class="block-body">
                        <ul class="dw-proprty-info">
                           <?php if($property->bedrooms): ?> <li><strong><?php echo e(__('lang.bedrooms')); ?></strong><?php echo e($property->bedrooms); ?></li> <?php endif; ?>
                           <?php if($property->bathrooms): ?> <li><strong><?php echo e(__('lang.bathrooms')); ?></strong><?php echo e($property->bathrooms); ?></li><?php endif; ?>
                            <?php if($property->garage): ?>
                            <li><strong><?php echo e(__('lang.garage')); ?></strong><?php echo e(__('lang.yes')); ?></li>
                            <?php endif; ?>
                            <li><strong><?php echo e(__('lang.area')); ?></strong><?php echo e($property->area); ?> m²</li>
                            <li><strong><?php echo e(__('lang.propertytype')); ?></strong>
                               <?php if($property->propertytype == 'houses'): ?>  <?php echo e(__('lang.houses')); ?>  <?php endif; ?>
                               <?php if($property->propertytype == 'apartment'): ?>  <?php echo e(__('lang.apartment')); ?>  <?php endif; ?>
                               <?php if($property->propertytype == 'villas'): ?>  <?php echo e(__('lang.villas')); ?>  <?php endif; ?>
                               <?php if($property->propertytype == 'commercial'): ?>  <?php echo e(__('lang.commercial')); ?>  <?php endif; ?>
                               <?php if($property->propertytype == 'offices'): ?>  <?php echo e(__('lang.offices')); ?>  <?php endif; ?>
                               <?php if($property->propertytype == 'garage'): ?>  <?php echo e(__('lang.garage')); ?>  <?php endif; ?>
                               <?php if($property->propertytype == 'ground'): ?>  <?php echo e(__('lang.ground')); ?>  <?php endif; ?>
                                
                            
                            </li>
                            <li><strong><?php echo e(__('lang.price')); ?></strong><?php echo e(config('helper.coin')); ?> <?php echo e($property->price); ?></li>

                            
                            <li><strong><?php echo e(__('lang.region')); ?></strong>
                              <a style="color:#7065ef;" href="<?php echo e(route('listing.properties',['state'=>$property->city->state->slug])); ?>"><?php echo e($property->city->state->state); ?></a>    
                            </li>
                            <li><strong><?php echo e(__('lang.city')); ?></strong>
                                <a style="color:#7065ef;" href="<?php echo e(route('listing.properties',['state'=>$property->city->state->slug,'city'=>$property->city->slug])); ?>"><?php echo e($property->city->city); ?></a></li>
                            <?php if($property->buildon): ?><li><strong><?php echo e(__('lang.buildon')); ?></strong>
                                <?php echo e($property->buildon); ?>

                            </li><?php endif; ?>
                            <li><strong><?php echo e(__('lang.energyclass')); ?></strong>
                                <span class="badge rounded-pill bg-success"><?php echo e($property->energy); ?></span>
                            </li>
                            <li><strong><?php echo e(__('lang.ges')); ?></strong>
                                <span class="badge rounded-pill bg-success"><?php echo e($property->ges); ?></span>
                            </li>
                            <li><strong><?php echo e(__('lang.zipcode')); ?></strong><?php echo e($property->zipcode); ?></li>
                        </ul>
                    </div>
                    
                </div>
                
                <!-- Single Block Wrap -->
                <div class="block-wrap">
                    
                    <div class="block-header">
                        <h4 class="block-title"><?php echo e(__('lang.description')); ?></h4>
                    </div>
                    
                    <div class="block-body">
                        <p><?php echo $property->description; ?></p>
                    </div>
                    
                </div>
                
                <!-- Single Block Wrap -->
                <div class="block-wrap">
                    
                    <div class="block-header">
                        <h4 class="block-title"><?php echo e(__('lang.amenities')); ?></h4>
                    </div>
                    
                    <div class="block-body">
                        <ul class="avl-features third">
                        
                             <?php if($property->features != null && count($property->features) > 0): ?>
                                 <?php $__currentLoopData = $property->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $features): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <?php if($features == 'equippedkitchen'): ?>   <li><?php echo e(__('lang.equippedkitchen')); ?></li> <?php endif; ?>
                                   <?php if($features == 'americankitchen'): ?>   <li><?php echo e(__('lang.americankitchen')); ?></li> <?php endif; ?>
                                   <?php if($features == 'separatetoilet'): ?>   <li><?php echo e(__('lang.separatetoilet')); ?></li> <?php endif; ?>
                                   <?php if($features == 'bathtub'): ?>   <li><?php echo e(__('lang.bathtub')); ?></li> <?php endif; ?>
                                   <?php if($features == 'fireplace'): ?>   <li><?php echo e(__('lang.fireplace')); ?></li> <?php endif; ?>
                                   <?php if($features == 'airconditioner'): ?>   <li><?php echo e(__('lang.airconditioner')); ?></li> <?php endif; ?>
                                   <?php if($features == 'cupboards'): ?>   <li><?php echo e(__('lang.cupboards')); ?></li> <?php endif; ?>
                                   <?php if($features == 'parquet'): ?>   <li><?php echo e(__('lang.parquet')); ?></li> <?php endif; ?>
                                   <?php if($features == 'alarm'): ?>   <li><?php echo e(__('lang.alarm')); ?></li> <?php endif; ?>
                                   <?php if($features == 'attic'): ?>   <li><?php echo e(__('lang.attic')); ?></li> <?php endif; ?>
                                   <?php if($features == 'balcony'): ?>   <li><?php echo e(__('lang.balcony')); ?></li> <?php endif; ?>
                                   <?php if($features == 'terrace'): ?>   <li><?php echo e(__('lang.terrace')); ?></li> <?php endif; ?>
                                   <?php if($features == 'garden'): ?>   <li><?php echo e(__('lang.garden')); ?></li> <?php endif; ?>
                                   <?php if($features == 'garageparking'): ?>   <li><?php echo e(__('lang.garageparking')); ?></li> <?php endif; ?>
                                   <?php if($features == 'cellar'): ?>   <li><?php echo e(__('lang.cellar')); ?></li> <?php endif; ?>
                                   <?php if($features == 'swimmingpool'): ?>   <li><?php echo e(__('lang.swimmingpool')); ?></li> <?php endif; ?>
                                   <?php if($features == 'tennis'): ?>   <li><?php echo e(__('lang.tennis')); ?></li> <?php endif; ?>
                                   <?php if($features == 'elevator'): ?>   <li><?php echo e(__('lang.elevator')); ?></li> <?php endif; ?>
                                   <?php if($features == 'guardian'): ?>   <li><?php echo e(__('lang.guardian')); ?></li> <?php endif; ?>
                                   <?php if($features == 'digicode'): ?>   <li><?php echo e(__('lang.digicode')); ?></li> <?php endif; ?>
                                   <?php if($features == 'intercom'): ?>   <li><?php echo e(__('lang.intercom')); ?></li> <?php endif; ?>
                                   <?php if($features == 'calm'): ?>   <li><?php echo e(__('lang.calm')); ?></li> <?php endif; ?>
                                   <?php if($features == 'heater'): ?>   <li><?php echo e(__('lang.heater')); ?></li> <?php endif; ?>
                                   <?php if($features == 'luminous'): ?>   <li><?php echo e(__('lang.luminous')); ?></li> <?php endif; ?>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             <?php endif; ?>
                        </ul>
                    </div>
                    
                </div>
                                
                
                
            </div>
            
    
            <!-- property Sidebar -->
            <div class="col-lg-4 col-md-12 col-sm-12">
                <div class="page-sidebar">
                    <!-- Agent Detail -->
                   <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('component.mail-property', ['idprop' => $property->id])->html();
} elseif ($_instance->childHasBeenRendered('FXt7QbS')) {
    $componentId = $_instance->getRenderedChildComponentId('FXt7QbS');
    $componentTag = $_instance->getRenderedChildComponentTagName('FXt7QbS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FXt7QbS');
} else {
    $response = \Livewire\Livewire::mount('component.mail-property', ['idprop' => $property->id]);
    $html = $response->html();
    $_instance->logRenderedChild('FXt7QbS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    
                     <?php if(count($propertyreleted) > 0): ?>
                    <!-- Featured Property -->
                    <div class="sidebar-widgets">
                        
                        <h4><?php echo e(__('lang.featuredproperty')); ?></h4>
                        
                        <div class="sidebar-property-slide">
                            <?php $__currentLoopData = $propertyreleted; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-items">
                                <div class="property-listing property-1">
                        
                                    <div class="listing-img-wrapper">
                                        <a href="<?php echo e(route('property',$item->slug)); ?>">
                                            <?php if(isset($item->thumbnails[0]) && !empty($item->thumbnails[0])): ?>
                                            <img src="<?php echo e(asset($item->thumbnails[0])); ?>" class="img-fluid mx-auto" alt="<?php echo e($item->title); ?>" /> 
                                            <?php else: ?> 
                                            <img src="<?php echo e(asset('images\property\thumbnail\default.jpg')); ?>" class="img-fluid mx-auto" alt="<?php echo e($item->title); ?>" />    
                                           <?php endif; ?>
                                        </a>
                                        <div class="listing-like-top">
                                            <i class="ti-heart"></i>
                                        </div>
                                        <div class="listing-rating">
                                            <i class="ti-star filled"></i>
                                            <i class="ti-star filled"></i>
                                            <i class="ti-star filled"></i>
                                            <i class="ti-star filled"></i>
                                            <i class="ti-star"></i>
                                        </div>
                                        <span class="property-type">
                                            <?php if($item->status == 'rent'): ?>
                                            <?php echo e(__('lang.forrent')); ?>             
                                            <?php else: ?>
                                            <?php echo e(__('lang.forsale')); ?>   
                                            <?php endif; ?>
                                        </span>
                                    </div>
                                    
                                    <div class="listing-content">
                                    
                                        <div class="listing-detail-wrapper">
                                            <div class="listing-short-detail">
                                                <h4 class="listing-name"><a href="<?php echo e(route('property',$item->slug)); ?>"><?php echo e($item->title); ?></a></h4>
                                                <span class="listing-location"><i class="ti-location-pin"></i><?php echo e($item->address); ?></span>
                                            </div>
                                        </div>
                                    
                                        <div class="listing-features-info">
                                            <ul>
                                               <?php if($item->bedrooms): ?> <li><strong><?php echo e(__('lang.beds')); ?>:</strong><?php echo e($item->bedrooms); ?></li><?php endif; ?>
                                               <?php if($item->bathrooms): ?>  <li><strong><?php echo e(__('lang.bath')); ?>:</strong><?php echo e($item->bathrooms); ?></li><?php endif; ?>
                                               <?php if($item->area): ?> <li><strong><?php echo e(__('lang.area')); ?>:</strong><?php echo e($item->area); ?></li><?php endif; ?>
                                            </ul>
                                        </div>
                                    
                                        <div class="listing-footer-wrapper">
                                            <div class="listing-price">
                                                <h4 class="list-pr"><?php echo e(config('helper.coin')); ?> <?php echo e($item->price); ?></h4>
                                            </div>
                                            <div class="listing-detail-btn">
                                                <a href="<?php echo e(route('property',$item->slug)); ?>" class="more-btn"><?php echo e(__('lang.moreinfo')); ?></a>
                                            </div>
                                        </div>
                                        
                                    </div>
                                    
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                    </div>
                    <?php endif; ?>
                
                </div>
            </div>
            
        </div>
    </div>
</section>
<?php endif; ?>
<?php if($theme == 2): ?>
<div class="single-advance-property gray">
    <div class="container-fluid p-0">
        <div class="row align-items-center">
        
            <div class="col-lg-7 col-md-7 col-sm-12">
                <div class="slider-for">
                    <?php if(isset($property->photos)   && count($property->photos) > 0): ?>
                    <?php $__currentLoopData = $property->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><a href="<?php echo e(asset($photo)); ?>" class="mfp-gallery"><img src="<?php echo e(asset($photo)); ?>" class="img-fluid mx-auto" alt="<?php echo e($property->title); ?>" /></a></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?> 
                    <div><a href="<?php echo e(asset('images\property\default.jpg')); ?>" class="mfp-gallery"><img src="<?php echo e(asset('images\property\default.jpg')); ?>" class="img-fluid mx-auto" alt="<?php echo e($property->title); ?>" /></a></div>
                    <?php endif; ?>
                </div>
                
            </div>
            
            <div class="col-lg-5 col-md-5 col-sm-12">
                <div class="single-advance-caption">
                
                    <div class="property-name-info">
                        <h4 class="property-name"><?php echo e($property->title); ?></h4>
                        <p class="property-desc"><?php echo e($property->address); ?></p>
                    </div>
                    
                    <div class="property-price-info">
                        <h4 class="property-price"><?php echo e(Config('helper.coin')); ?> <?php echo e($property->price); ?></h4>
                        <p class="property-sqa"><?php echo e($property->area); ?> <sub>/ m2</sub></p>
                    </div>
                    
                    <div class="property-statement">
                        <ul>
                            <li>
                                <i class="lni-apartment"></i>
                                <div class="ps-trep">
                                    <span><?php echo e(__('lang.propertytype')); ?></span>
                                    <?php if($property->propertytype == 'houses'): ?> <h5 class="ps-type"> <?php echo e(__('lang.houses')); ?> </h5>  <?php endif; ?>
                                    <?php if($property->propertytype == 'apartment'): ?> <h5 class="ps-type"> <?php echo e(__('lang.apartment')); ?> </h5> <?php endif; ?>
                                    <?php if($property->propertytype == 'villas'): ?>  <h5 class="ps-type"> <?php echo e(__('lang.villas')); ?> </h5> <?php endif; ?>
                                    <?php if($property->propertytype == 'commercial'): ?> <h5 class="ps-type"> <?php echo e(__('lang.commercial')); ?> </h5> <?php endif; ?>
                                    <?php if($property->propertytype == 'offices'): ?> <h5 class="ps-type">  <?php echo e(__('lang.offices')); ?> </h5> <?php endif; ?>
                                    <?php if($property->propertytype == 'garage'): ?> <h5 class="ps-type">  <?php echo e(__('lang.garage')); ?> </h5> <?php endif; ?>
                                    <?php if($property->propertytype == 'ground'): ?> <h5 class="ps-type">  <?php echo e(__('lang.ground')); ?> </h5>  <?php endif; ?>
                                </div>
                            </li>
                            <?php if($property->buildon): ?>
                            <li>
                                <i class="lni-restaurant"></i>
                                <div class="ps-trep">
                                
                                    <span><?php echo e(__('lang.buildon')); ?></span>
                                    <h5 class="ps-type"><?php echo e($property->buildon); ?></h5>
                                    
                                </div>
                            </li>
                            <?php endif; ?>
                            <li>
                                <i class="lni lni-map"></i>
                                <div class="ps-trep">
                                    <span><?php echo e(__('lang.region')); ?></span>
                                    <h5 class="ps-type">
                                       <a style="color:#7065ef;" href="<?php echo e(route('listing.properties',['state'=>$property->city->state->slug])); ?>">
                                         <?php echo e($property->city->state->state); ?>

                                       </a> 
                                    </h5>
                                </div>
                            </li>
                            <li>
                                <i class="lni lni-map-marker"></i>
                                <div class="ps-trep">
                                    <span><?php echo e(__('lang.city')); ?></span>
                                    <h5 class="ps-type">
                                        <a style="color:#7065ef;" href="<?php echo e(route('listing.properties',['state'=>$property->city->state->slug,'city'=>$property->city->slug])); ?>"><?php echo e($property->city->city); ?></a>
                                     </h5>
                                </div>
                            </li>
                        </ul>
                    </div>
                    
                </div>
            </div>
        
        </div>
        
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="slider-nav">
                    <?php if(isset($property->photos)   && count($property->photos) > 0): ?>
                    <?php $__currentLoopData = $property->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><a href="<?php echo e(asset($photo)); ?>" class="mfp-gallery"><img src="<?php echo e(asset($photo)); ?>" class="img-fluid mx-auto" alt="<?php echo e($property->title); ?>" /></a></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?> 
                    <div><a href="<?php echo e(asset('images\property\default.jpg')); ?>" class="mfp-gallery"><img src="<?php echo e(asset('images\property\default.jpg')); ?>" class="img-fluid mx-auto" alt="<?php echo e($property->title); ?>" /></a></div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<section class="spd-wrap">
    <div class="container">
        <div class="row">
            
            <div class="col-lg-12 col-md-12">
            
                <div class="slide-property-detail">
                    
                    <div class="slide-property-first">
                        <div class="pr-price-into">
                            <?php if($property->status == 'sale'): ?> <h2><?php echo e(Config('helper.coin')); ?> <?php echo e($property->price); ?><i>/ </i> <span class="prt-type sale"><?php echo e(__('lang.forsale')); ?></span></h2><?php endif; ?>
                            <?php if($property->status == 'rent'): ?> <h2><?php echo e(Config('helper.coin')); ?> <?php echo e($property->price); ?><i>/ </i> <span class="prt-type sale"><?php echo e(__('lang.forrent')); ?></span></h2><?php endif; ?>
                            <span><i class="lni-map-marker"></i> <?php echo e($property->address); ?></span>
                        </div>
                    </div>
                    
                    <div class="slide-property-sec">
                        <div class="pr-all-info">
                            
                            <div class="pr-single-info">
                                <div class="share-opt-wrap">
                                    <button type="button" class="btn-share" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-original-title="Share this">
                                        <i class="lni-share"></i>
                                    </button>
                                    <div class="dropdown-menu animated flipInX">
                                        <a  href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(url()->current()); ?>&t=<?php echo e($property->title); ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" target="_blank" title="<?php echo e(__('lang.shareonfacebook')); ?>"  class="cl-facebook"><i class="lni-facebook"></i></a>
                                        <a href="https://twitter.com/share?url=<?php echo e(url()->current()); ?>&text=<?php echo e($property->title); ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" target="_blank" title="<?php echo e(__('lang.shareontwitter')); ?>" class="cl-twitter"><i class="lni-twitter"></i></a>
                                        <a href="whatsapp://send?text=<?php echo e(url()->current()); ?>" data-action="share/whatsapp/share" onClick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" target="_blank" title="<?php echo e(__('lang.shareonwhatsapp')); ?>" class="cl-whatsapp"><i class="lni-whatsapp"></i></a>
                                        
                                    </div>
                                </div>

                            </div>
                            
                            <div class="pr-single-info">
                                <a href="<?php echo e(route('property.pdf',$property->slug)); ?>" data-toggle="tooltip" data-original-title="Get Print"><i class="ti-printer"></i></a>
                            </div>
                            
                          
                        </div>
                    </div>
                    
                </div>
                
            </div>
        </div>
    </div>
</section>
<section class="gray">
    <div class="container">
        <div class="row">
            
            <!-- property main detail -->
            <div class="col-lg-8 col-md-12 col-sm-12">
                
                <!-- Single Block Wrap -->
                <div class="block-wrap">
                    
                    <div class="block-header">
                        <h4 class="block-title"><?php echo e(__('lang.propertyinfo')); ?></h4>
                    </div>
                    
                    <div class="block-body">
                        <ul class="dw-proprty-info">
                           <?php if($property->bedrooms): ?> <li><strong><?php echo e(__('lang.bedrooms')); ?></strong><?php echo e($property->bedrooms); ?></li> <?php endif; ?>
                           <?php if($property->bathrooms): ?> <li><strong><?php echo e(__('lang.bathrooms')); ?></strong><?php echo e($property->bathrooms); ?></li><?php endif; ?>
                            <?php if($property->garage): ?>
                            <li><strong><?php echo e(__('lang.garage')); ?></strong><?php echo e(__('lang.yes')); ?></li>
                            <?php endif; ?>
                            <li><strong><?php echo e(__('lang.area')); ?></strong><?php echo e($property->area); ?> m²</li>
                            <li><strong><?php echo e(__('lang.propertytype')); ?></strong>
                               <?php if($property->propertytype == 'houses'): ?>  <?php echo e(__('lang.houses')); ?>  <?php endif; ?>
                               <?php if($property->propertytype == 'apartment'): ?>  <?php echo e(__('lang.apartment')); ?>  <?php endif; ?>
                               <?php if($property->propertytype == 'villas'): ?>  <?php echo e(__('lang.villas')); ?>  <?php endif; ?>
                               <?php if($property->propertytype == 'commercial'): ?>  <?php echo e(__('lang.commercial')); ?>  <?php endif; ?>
                               <?php if($property->propertytype == 'offices'): ?>  <?php echo e(__('lang.offices')); ?>  <?php endif; ?>
                               <?php if($property->propertytype == 'garage'): ?>  <?php echo e(__('lang.garage')); ?>  <?php endif; ?>
                               <?php if($property->propertytype == 'ground'): ?>  <?php echo e(__('lang.ground')); ?>  <?php endif; ?>
                                
                            
                            </li>
                            <li><strong><?php echo e(__('lang.price')); ?></strong><?php echo e(config('helper.coin')); ?> <?php echo e($property->price); ?></li>

                            
                            <li><strong><?php echo e(__('lang.region')); ?></strong>
                              <a style="color:#7065ef;" href="<?php echo e(route('listing.properties',['state'=>$property->city->state->slug])); ?>"><?php echo e($property->city->state->state); ?></a>    
                            </li>
                            <li><strong><?php echo e(__('lang.city')); ?></strong>
                                <a style="color:#7065ef;" href="<?php echo e(route('listing.properties',['state'=>$property->city->state->slug,'city'=>$property->city->slug])); ?>"><?php echo e($property->city->city); ?></a></li>
                            <?php if($property->buildon): ?><li><strong><?php echo e(__('lang.buildon')); ?></strong>
                                <?php echo e($property->buildon); ?>

                            </li><?php endif; ?>
                            <li><strong><?php echo e(__('lang.energyclass')); ?></strong>
                                <span class="badge rounded-pill bg-success"><?php echo e($property->energy); ?></span>
                            </li>
                            <li><strong><?php echo e(__('lang.ges')); ?></strong>
                                <span class="badge rounded-pill bg-success"><?php echo e($property->ges); ?></span>
                            </li>
                            <li><strong><?php echo e(__('lang.zipcode')); ?></strong><?php echo e($property->zipcode); ?></li>
                        </ul>
                    </div>
                    
                </div>
                
                <!-- Single Block Wrap -->
                <div class="block-wrap">
                    
                    <div class="block-header">
                        <h4 class="block-title"><?php echo e(__('lang.description')); ?></h4>
                    </div>
                    
                    <div class="block-body">
                        <p><?php echo $property->description; ?></p>
                    </div>
                    
                </div>
                
                <!-- Single Block Wrap -->
                <div class="block-wrap">
                    
                    <div class="block-header">
                        <h4 class="block-title"><?php echo e(__('lang.amenities')); ?></h4>
                    </div>
                    
                    <div class="block-body">
                        <ul class="avl-features third">
                        
                             <?php if($property->features != null && count($property->features) > 0): ?>
                                 <?php $__currentLoopData = $property->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $features): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <?php if($features == 'equippedkitchen'): ?>   <li><?php echo e(__('lang.equippedkitchen')); ?></li> <?php endif; ?>
                                   <?php if($features == 'americankitchen'): ?>   <li><?php echo e(__('lang.americankitchen')); ?></li> <?php endif; ?>
                                   <?php if($features == 'separatetoilet'): ?>   <li><?php echo e(__('lang.separatetoilet')); ?></li> <?php endif; ?>
                                   <?php if($features == 'bathtub'): ?>   <li><?php echo e(__('lang.bathtub')); ?></li> <?php endif; ?>
                                   <?php if($features == 'fireplace'): ?>   <li><?php echo e(__('lang.fireplace')); ?></li> <?php endif; ?>
                                   <?php if($features == 'airconditioner'): ?>   <li><?php echo e(__('lang.airconditioner')); ?></li> <?php endif; ?>
                                   <?php if($features == 'cupboards'): ?>   <li><?php echo e(__('lang.cupboards')); ?></li> <?php endif; ?>
                                   <?php if($features == 'parquet'): ?>   <li><?php echo e(__('lang.parquet')); ?></li> <?php endif; ?>
                                   <?php if($features == 'alarm'): ?>   <li><?php echo e(__('lang.alarm')); ?></li> <?php endif; ?>
                                   <?php if($features == 'attic'): ?>   <li><?php echo e(__('lang.attic')); ?></li> <?php endif; ?>
                                   <?php if($features == 'balcony'): ?>   <li><?php echo e(__('lang.balcony')); ?></li> <?php endif; ?>
                                   <?php if($features == 'terrace'): ?>   <li><?php echo e(__('lang.terrace')); ?></li> <?php endif; ?>
                                   <?php if($features == 'garden'): ?>   <li><?php echo e(__('lang.garden')); ?></li> <?php endif; ?>
                                   <?php if($features == 'garageparking'): ?>   <li><?php echo e(__('lang.garageparking')); ?></li> <?php endif; ?>
                                   <?php if($features == 'cellar'): ?>   <li><?php echo e(__('lang.cellar')); ?></li> <?php endif; ?>
                                   <?php if($features == 'swimmingpool'): ?>   <li><?php echo e(__('lang.swimmingpool')); ?></li> <?php endif; ?>
                                   <?php if($features == 'tennis'): ?>   <li><?php echo e(__('lang.tennis')); ?></li> <?php endif; ?>
                                   <?php if($features == 'elevator'): ?>   <li><?php echo e(__('lang.elevator')); ?></li> <?php endif; ?>
                                   <?php if($features == 'guardian'): ?>   <li><?php echo e(__('lang.guardian')); ?></li> <?php endif; ?>
                                   <?php if($features == 'digicode'): ?>   <li><?php echo e(__('lang.digicode')); ?></li> <?php endif; ?>
                                   <?php if($features == 'intercom'): ?>   <li><?php echo e(__('lang.intercom')); ?></li> <?php endif; ?>
                                   <?php if($features == 'calm'): ?>   <li><?php echo e(__('lang.calm')); ?></li> <?php endif; ?>
                                   <?php if($features == 'heater'): ?>   <li><?php echo e(__('lang.heater')); ?></li> <?php endif; ?>
                                   <?php if($features == 'luminous'): ?>   <li><?php echo e(__('lang.luminous')); ?></li> <?php endif; ?>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             <?php endif; ?>
                        </ul>
                    </div>
                    
                </div>
                                
                
                
            </div>
            
    
            <!-- property Sidebar -->
            <div class="col-lg-4 col-md-12 col-sm-12">
                <div class="page-sidebar">
                    <!-- Agent Detail -->
                   <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('component.mail-property', ['idprop' => $property->id])->html();
} elseif ($_instance->childHasBeenRendered('MfPWe17')) {
    $componentId = $_instance->getRenderedChildComponentId('MfPWe17');
    $componentTag = $_instance->getRenderedChildComponentTagName('MfPWe17');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('MfPWe17');
} else {
    $response = \Livewire\Livewire::mount('component.mail-property', ['idprop' => $property->id]);
    $html = $response->html();
    $_instance->logRenderedChild('MfPWe17', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    
                     <?php if(count($propertyreleted) > 0): ?>
                    <!-- Featured Property -->
                    <div class="sidebar-widgets">
                        
                        <h4><?php echo e(__('lang.featuredproperty')); ?></h4>
                        
                        <div class="sidebar-property-slide">
                            <?php $__currentLoopData = $propertyreleted; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-items">
                                <div class="property-listing property-1">
                        
                                    <div class="listing-img-wrapper">
                                        <a href="<?php echo e(route('property',$item->slug)); ?>">
                                            <?php if(isset($item->thumbnails[0]) && !empty($item->thumbnails[0])): ?>
                                             <img src="<?php echo e(asset($item->thumbnails[0])); ?>" class="img-fluid mx-auto" alt="<?php echo e($item->title); ?>" /> 
                                             <?php else: ?> 
                                             <img src="<?php echo e(asset('images\property\thumbnail\default.jpg')); ?>" class="img-fluid mx-auto" alt="<?php echo e($item->title); ?>" />    
                                            <?php endif; ?>
                                            
                                        </a>
                                        <div class="listing-like-top">
                                            <i class="ti-heart"></i>
                                        </div>
                                        <div class="listing-rating">
                                            <i class="ti-star filled"></i>
                                            <i class="ti-star filled"></i>
                                            <i class="ti-star filled"></i>
                                            <i class="ti-star filled"></i>
                                            <i class="ti-star"></i>
                                        </div>
                                        <span class="property-type">
                                            <?php if($item->status == 'rent'): ?>
                                            <?php echo e(__('lang.forrent')); ?>             
                                            <?php else: ?>
                                            <?php echo e(__('lang.forsale')); ?>   
                                            <?php endif; ?>
                                        </span>
                                    </div>
                                    
                                    <div class="listing-content">
                                    
                                        <div class="listing-detail-wrapper">
                                            <div class="listing-short-detail">
                                                <h4 class="listing-name"><a href="<?php echo e(route('property',$item->slug)); ?>"><?php echo e($item->title); ?></a></h4>
                                                <span class="listing-location"><i class="ti-location-pin"></i><?php echo e($item->address); ?></span>
                                            </div>
                                        </div>
                                    
                                        <div class="listing-features-info">
                                            <ul>
                                               <?php if($item->bedrooms): ?> <li><strong><?php echo e(__('lang.beds')); ?>:</strong><?php echo e($item->bedrooms); ?></li><?php endif; ?>
                                               <?php if($item->bathrooms): ?>  <li><strong><?php echo e(__('lang.bath')); ?>:</strong><?php echo e($item->bathrooms); ?></li><?php endif; ?>
                                               <?php if($item->area): ?> <li><strong><?php echo e(__('lang.area')); ?>:</strong><?php echo e($item->area); ?></li><?php endif; ?>
                                            </ul>
                                        </div>
                                    
                                        <div class="listing-footer-wrapper">
                                            <div class="listing-price">
                                                <h4 class="list-pr"><?php echo e(config('helper.coin')); ?> <?php echo e($item->price); ?></h4>
                                            </div>
                                            <div class="listing-detail-btn">
                                                <a href="<?php echo e(route('property',$item->slug)); ?>" class="more-btn"><?php echo e(__('lang.moreinfo')); ?></a>
                                            </div>
                                        </div>
                                        
                                    </div>
                                    
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                    </div>
                    <?php endif; ?>

                    
                
                </div>
            </div>
            
        </div>
    </div>
</section>
<?php endif; ?>
<?php if($theme == 3): ?>
<section class="gray">
    <div class="container">
        <div class="row">
            
            <!-- property main detail -->
            <div class="col-lg-8 col-md-12 col-sm-12">
                <h1 style="font-size:2em;"><?php echo e($property->title); ?></h1>
                <div class="slide-property-first mb-4">
                    <div class="pr-price-into">
                        <h2><?php echo e(config('helper.coin')); ?> <?php echo e($property->price); ?> 
                            <?php if($property->status == 'sale'): ?>   <span class="prt-type sale"><?php echo e(__('lang.forsale')); ?></span> <?php endif; ?>
                            <?php if($property->status == 'rent'): ?>   <span class="prt-type rent"><?php echo e(__('lang.forrent')); ?></span> <?php endif; ?>
                        </h2>
                        <span><i class="lni-map-marker"></i> <?php echo e($property->address); ?></span>
                    </div>
                </div>
                    
                <div class="property3-slide single-advance-property mb-4">
            
                    <div class="slider-for">
                        <?php if(isset($property->photos)   && count($property->photos) > 0): ?>
                        <?php $__currentLoopData = $property->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div><a href="<?php echo e(asset($photo)); ?>" class="mfp-gallery"><img src="<?php echo e(asset($photo)); ?>" class="img-fluid mx-auto" alt="<?php echo e($property->title); ?>" /></a></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?> 
                        <div><a href="<?php echo e(asset('images\property\default.jpg')); ?>" class="mfp-gallery"><img src="<?php echo e(asset('images\property\default.jpg')); ?>" class="img-fluid mx-auto" alt="<?php echo e($property->title); ?>" /></a></div>
                        <?php endif; ?>
                    </div>
                    <div class="slider-nav">
                        <?php if(isset($property->photos)   && count($property->photos) > 0): ?>
                        <?php $__currentLoopData = $property->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item-slick"><img src="<?php echo e(asset($photo)); ?>" alt="<?php echo e($property->title); ?>"></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?> 
                        <div class="item-slick"><img src="<?php echo e(asset('images\property\default.jpg')); ?>" alt="<?php echo e($property->title); ?>" title="<?php echo e($property->title); ?>"></div>
                        <?php endif; ?>
                    </div>
                    
                </div>
                
                <div class="block-wrap">
                    
                    <div class="block-header">
                        <h4 class="block-title"><?php echo e(__('lang.propertyinfo')); ?></h4>
                    </div>
                    
                    <div class="block-body">
                        <ul class="dw-proprty-info">
                           <?php if($property->bedrooms): ?> <li><strong><?php echo e(__('lang.bedrooms')); ?></strong><?php echo e($property->bedrooms); ?></li> <?php endif; ?>
                           <?php if($property->bathrooms): ?> <li><strong><?php echo e(__('lang.bathrooms')); ?></strong><?php echo e($property->bathrooms); ?></li><?php endif; ?>
                            <?php if($property->garage): ?>
                            <li><strong><?php echo e(__('lang.garage')); ?></strong><?php echo e(__('lang.yes')); ?></li>
                            <?php endif; ?>
                            <li><strong><?php echo e(__('lang.area')); ?></strong><?php echo e($property->area); ?> m²</li>
                            <li><strong><?php echo e(__('lang.propertytype')); ?></strong>
                               <?php if($property->propertytype == 'houses'): ?>  <?php echo e(__('lang.houses')); ?>  <?php endif; ?>
                               <?php if($property->propertytype == 'apartment'): ?>  <?php echo e(__('lang.apartment')); ?>  <?php endif; ?>
                               <?php if($property->propertytype == 'villas'): ?>  <?php echo e(__('lang.villas')); ?>  <?php endif; ?>
                               <?php if($property->propertytype == 'commercial'): ?>  <?php echo e(__('lang.commercial')); ?>  <?php endif; ?>
                               <?php if($property->propertytype == 'offices'): ?>  <?php echo e(__('lang.offices')); ?>  <?php endif; ?>
                               <?php if($property->propertytype == 'garage'): ?>  <?php echo e(__('lang.garage')); ?>  <?php endif; ?>
                               <?php if($property->propertytype == 'ground'): ?>  <?php echo e(__('lang.ground')); ?>  <?php endif; ?>
                                
                            
                            </li>
                            <li><strong><?php echo e(__('lang.price')); ?></strong><?php echo e(config('helper.coin')); ?> <?php echo e($property->price); ?></li>

                            
                            <li><strong><?php echo e(__('lang.region')); ?></strong>
                              <a style="color:#7065ef;" href="<?php echo e(route('listing.properties',['state'=>$property->city->state->slug])); ?>"><?php echo e($property->city->state->state); ?></a>    
                            </li>
                            <li><strong><?php echo e(__('lang.city')); ?></strong>
                                <a style="color:#7065ef;" href="<?php echo e(route('listing.properties',['state'=>$property->city->state->slug,'city'=>$property->city->slug])); ?>"><?php echo e($property->city->city); ?></a></li>
                            <?php if($property->buildon): ?><li><strong><?php echo e(__('lang.buildon')); ?></strong>
                                <?php echo e($property->buildon); ?>

                            </li><?php endif; ?>
                            <li><strong><?php echo e(__('lang.energyclass')); ?></strong>
                                <span class="badge rounded-pill bg-success"><?php echo e($property->energy); ?></span>
                            </li>
                            <li><strong><?php echo e(__('lang.ges')); ?></strong>
                                <span class="badge rounded-pill bg-success"><?php echo e($property->ges); ?></span>
                            </li>
                            <li><strong><?php echo e(__('lang.zipcode')); ?></strong><?php echo e($property->zipcode); ?></li>
                        </ul>
                    </div>
                    
                </div>
                
                <!-- Single Block Wrap -->
                <div class="block-wrap">
                    
                    <div class="block-header">
                        <h4 class="block-title"><?php echo e(__('lang.description')); ?></h4>
                    </div>
                    
                    <div class="block-body">
                        <p><?php echo $property->description; ?></p>
                    </div>
                    
                </div>
                
                <!-- Single Block Wrap -->
                <div class="block-wrap">
                    
                    <div class="block-header">
                        <h4 class="block-title"><?php echo e(__('lang.amenities')); ?></h4>
                    </div>
                    
                    <div class="block-body">
                        <ul class="avl-features third">
                        
                             <?php if($property->features != null && count($property->features) > 0): ?>
                                 <?php $__currentLoopData = $property->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $features): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <?php if($features == 'equippedkitchen'): ?>   <li><?php echo e(__('lang.equippedkitchen')); ?></li> <?php endif; ?>
                                   <?php if($features == 'americankitchen'): ?>   <li><?php echo e(__('lang.americankitchen')); ?></li> <?php endif; ?>
                                   <?php if($features == 'separatetoilet'): ?>   <li><?php echo e(__('lang.separatetoilet')); ?></li> <?php endif; ?>
                                   <?php if($features == 'bathtub'): ?>   <li><?php echo e(__('lang.bathtub')); ?></li> <?php endif; ?>
                                   <?php if($features == 'fireplace'): ?>   <li><?php echo e(__('lang.fireplace')); ?></li> <?php endif; ?>
                                   <?php if($features == 'airconditioner'): ?>   <li><?php echo e(__('lang.airconditioner')); ?></li> <?php endif; ?>
                                   <?php if($features == 'cupboards'): ?>   <li><?php echo e(__('lang.cupboards')); ?></li> <?php endif; ?>
                                   <?php if($features == 'parquet'): ?>   <li><?php echo e(__('lang.parquet')); ?></li> <?php endif; ?>
                                   <?php if($features == 'alarm'): ?>   <li><?php echo e(__('lang.alarm')); ?></li> <?php endif; ?>
                                   <?php if($features == 'attic'): ?>   <li><?php echo e(__('lang.attic')); ?></li> <?php endif; ?>
                                   <?php if($features == 'balcony'): ?>   <li><?php echo e(__('lang.balcony')); ?></li> <?php endif; ?>
                                   <?php if($features == 'terrace'): ?>   <li><?php echo e(__('lang.terrace')); ?></li> <?php endif; ?>
                                   <?php if($features == 'garden'): ?>   <li><?php echo e(__('lang.garden')); ?></li> <?php endif; ?>
                                   <?php if($features == 'garageparking'): ?>   <li><?php echo e(__('lang.garageparking')); ?></li> <?php endif; ?>
                                   <?php if($features == 'cellar'): ?>   <li><?php echo e(__('lang.cellar')); ?></li> <?php endif; ?>
                                   <?php if($features == 'swimmingpool'): ?>   <li><?php echo e(__('lang.swimmingpool')); ?></li> <?php endif; ?>
                                   <?php if($features == 'tennis'): ?>   <li><?php echo e(__('lang.tennis')); ?></li> <?php endif; ?>
                                   <?php if($features == 'elevator'): ?>   <li><?php echo e(__('lang.elevator')); ?></li> <?php endif; ?>
                                   <?php if($features == 'guardian'): ?>   <li><?php echo e(__('lang.guardian')); ?></li> <?php endif; ?>
                                   <?php if($features == 'digicode'): ?>   <li><?php echo e(__('lang.digicode')); ?></li> <?php endif; ?>
                                   <?php if($features == 'intercom'): ?>   <li><?php echo e(__('lang.intercom')); ?></li> <?php endif; ?>
                                   <?php if($features == 'calm'): ?>   <li><?php echo e(__('lang.calm')); ?></li> <?php endif; ?>
                                   <?php if($features == 'heater'): ?>   <li><?php echo e(__('lang.heater')); ?></li> <?php endif; ?>
                                   <?php if($features == 'luminous'): ?>   <li><?php echo e(__('lang.luminous')); ?></li> <?php endif; ?>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             <?php endif; ?>
                        </ul>
                    </div>
                    
                </div>                
            </div>
            
            <!-- property Sidebar -->
            <div class="col-lg-4 col-md-12 col-sm-12">
                <div class="page-sidebar">
                    
                    <!-- slide-property-sec -->
                    <div class="slide-property-sec mb-4">
                        <div class="pr-all-info">
                            
                            <div class="pr-single-info">
                                <div class="share-opt-wrap">
                                    <button type="button" class="btn-share" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-original-title="Share this">
                                        <i class="lni-share"></i>
                                    </button>
                                    <div class="dropdown-menu animated flipInX">
                                        <a  href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(url()->current()); ?>&t=<?php echo e($property->title); ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" target="_blank" title="<?php echo e(__('lang.shareonfacebook')); ?>"  class="cl-facebook"><i class="lni-facebook"></i></a>
                                        <a href="https://twitter.com/share?url=<?php echo e(url()->current()); ?>&text=<?php echo e($property->title); ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" target="_blank" title="<?php echo e(__('lang.shareontwitter')); ?>" class="cl-twitter"><i class="lni-twitter"></i></a>
                                        <a href="whatsapp://send?text=<?php echo e(url()->current()); ?>" data-action="share/whatsapp/share" onClick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" target="_blank" title="<?php echo e(__('lang.shareonwhatsapp')); ?>" class="cl-whatsapp"><i class="lni-whatsapp"></i></a>
                                        
                                    </div>
                                </div>

                            </div>
                            
                            <div class="pr-single-info">
                                <a href="<?php echo e(route('property.pdf',$property->slug)); ?>" data-toggle="tooltip" data-original-title="Get Print"><i class="ti-printer"></i></a>
                            </div>
                            
                          
                        </div>
                    </div>
                    
                    <!-- Agent Detail -->
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('component.mail-property', ['idprop' => $property->id])->html();
} elseif ($_instance->childHasBeenRendered('yNe306e')) {
    $componentId = $_instance->getRenderedChildComponentId('yNe306e');
    $componentTag = $_instance->getRenderedChildComponentTagName('yNe306e');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('yNe306e');
} else {
    $response = \Livewire\Livewire::mount('component.mail-property', ['idprop' => $property->id]);
    $html = $response->html();
    $_instance->logRenderedChild('yNe306e', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    
                    <?php if(count($propertyreleted) > 0): ?>
                    <!-- Featured Property -->
                    <div class="sidebar-widgets">
                        
                        <h4><?php echo e(__('lang.featuredproperty')); ?></h4>
                        
                        <div class="sidebar-property-slide">
                            <?php $__currentLoopData = $propertyreleted; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-items">
                                <div class="property-listing property-1">
                        
                                    <div class="listing-img-wrapper">
                                        <a href="<?php echo e(route('property',$item->slug)); ?>">
                                            <?php if(isset($item->thumbnails[0]) && !empty($item->thumbnails[0])): ?>
                                            <img src="<?php echo e(asset($item->thumbnails[0])); ?>" class="img-fluid mx-auto" alt="<?php echo e($item->title); ?>" /> 
                                            <?php else: ?> 
                                            <img src="<?php echo e(asset('images\property\thumbnail\default.jpg')); ?>" class="img-fluid mx-auto" alt="<?php echo e($item->title); ?>" />    
                                           <?php endif; ?>
                                        </a>
                                        <div class="listing-like-top">
                                            <i class="ti-heart"></i>
                                        </div>
                                        <div class="listing-rating">
                                            <i class="ti-star filled"></i>
                                            <i class="ti-star filled"></i>
                                            <i class="ti-star filled"></i>
                                            <i class="ti-star filled"></i>
                                            <i class="ti-star"></i>
                                        </div>
                                        <span class="property-type">
                                            <?php if($item->status == 'rent'): ?>
                                            <?php echo e(__('lang.forrent')); ?>             
                                            <?php else: ?>
                                            <?php echo e(__('lang.forsale')); ?>   
                                            <?php endif; ?>
                                        </span>
                                    </div>
                                    
                                    <div class="listing-content">
                                    
                                        <div class="listing-detail-wrapper">
                                            <div class="listing-short-detail">
                                                <h4 class="listing-name"><a href="<?php echo e(route('property',$item->slug)); ?>"><?php echo e($item->title); ?></a></h4>
                                                <span class="listing-location"><i class="ti-location-pin"></i><?php echo e($item->address); ?></span>
                                            </div>
                                        </div>
                                    
                                        <div class="listing-features-info">
                                            <ul>
                                               <?php if($item->bedrooms): ?> <li><strong><?php echo e(__('lang.beds')); ?>:</strong><?php echo e($item->bedrooms); ?></li><?php endif; ?>
                                               <?php if($item->bathrooms): ?>  <li><strong><?php echo e(__('lang.bath')); ?>:</strong><?php echo e($item->bathrooms); ?></li><?php endif; ?>
                                               <?php if($item->area): ?> <li><strong><?php echo e(__('lang.area')); ?>:</strong><?php echo e($item->area); ?></li><?php endif; ?>
                                            </ul>
                                        </div>
                                    
                                        <div class="listing-footer-wrapper">
                                            <div class="listing-price">
                                                <h4 class="list-pr"><?php echo e(config('helper.coin')); ?> <?php echo e($item->price); ?></h4>
                                            </div>
                                            <div class="listing-detail-btn">
                                                <a href="<?php echo e(route('property',$item->slug)); ?>" class="more-btn"><?php echo e(__('lang.moreinfo')); ?></a>
                                            </div>
                                        </div>
                                        
                                    </div>
                                    
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
        </div>
    </div>
    
</section>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/diabcoog/gif/resources/views/property.blade.php ENDPATH**/ ?>